/* Garra — núcleo: configuração, rede, cliente do OBS (WebSocket v5) e cliente do Garra Hub */
'use strict';

const APP = {
  name: 'Garra',
  version: '0.9.2 beta',
  hubPort: 8650,
  obsPort: 4455,
  supportEmail: '',            // ex.: 'contato@seudominio.com' (aparece em Ajustes > Enviar feedback)
  hubDownloadUrl: '',          // link de download do Garra Hub (Drive/GitHub). Vazio = mostra instruções.
  privacyUrl: 'privacy.html'
};

/* ---------------- utilidades ---------------- */
class Emitter {
  constructor() { this._h = {}; }
  on(ev, fn) { (this._h[ev] = this._h[ev] || []).push(fn); return () => this.off(ev, fn); }
  off(ev, fn) { const a = this._h[ev]; if (a) this._h[ev] = a.filter(f => f !== fn); }
  emit(ev, ...args) { (this._h[ev] || []).slice().forEach(fn => { try { fn(...args); } catch (e) { console.error(e); } }); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ---------------- configuração salva no aparelho ---------------- */
const Cfg = {
  key: 'garra.v1',
  data: null,
  defaults() {
    return {
      onboarded: false,
      hub: null,                                   // {host, port, token, name}
      obs: { host: '', port: 4455, pass: '', fromHub: true },
      prefs: { haptics: true, awake: true, confirmStop: true, meters: true, size: 'm', mic: '' },
      favs: []
    };
  },
  load() {
    let d = null;
    try { d = JSON.parse(localStorage.getItem(this.key) || 'null'); } catch (e) { d = null; }
    const def = this.defaults();
    this.data = Object.assign(def, d || {});
    this.data.obs = Object.assign(def.obs, (d && d.obs) || {});
    this.data.prefs = Object.assign(def.prefs, (d && d.prefs) || {});
    return this.data;
  },
  save() { try { localStorage.setItem(this.key, JSON.stringify(this.data)); } catch (e) { } }
};

/* ---------------- ponte com o app Android (quando existe) ---------------- */
const Native = (function () {
  const n = window.GarraNative;
  if (!n) return null;
  let seq = 0; const cbs = {};
  window.__garraCb = function (id, json) {
    const cb = cbs[id]; if (!cb) return; delete cbs[id];
    let v = null; try { v = JSON.parse(json); } catch (e) { v = null; }
    cb(v);
  };
  function call(fn, ...args) {
    return new Promise(res => {
      const id = 'n' + (++seq); cbs[id] = res;
      try { n[fn](id, ...args); } catch (e) { delete cbs[id]; res(null); }
    });
  }
  const safe = (f, d) => { try { return f(); } catch (e) { return d; } };
  return {
    http: (method, url, body, timeout) => call('http', method, url, body || '', timeout || 6000),
    scan: (ports, timeout) => call('scan', ports.join(','), timeout || 450),
    wake: (mac, bcast) => n.wake ? call('wake', mac, bcast || '') : Promise.resolve(null),
    canWake: () => !!n.wake,
    haptic: k => safe(() => n.haptic(k)),
    keepAwake: v => safe(() => n.keepAwake(!!v)),
    open: u => safe(() => n.openExternal(u)),
    version: () => safe(() => n.version(), ''),
    localIp: () => safe(() => n.localIp(), ''),
    device: () => safe(() => n.deviceName(), 'Android')
  };
})();

function openExternal(url) {
  if (Native) Native.open(url); else window.open(url, '_blank', 'noopener');
}

/* ---------------- HTTP (nativo no Android, fetch no navegador) ---------------- */
async function httpJson(method, url, body, timeout) {
  timeout = timeout || 6000;
  const payload = body == null ? '' : (typeof body === 'string' ? body : JSON.stringify(body));
  let r;
  const sameOrigin = location.protocol.startsWith('http') && url.indexOf(location.origin + '/') === 0;
  if (Native && !sameOrigin) {
    r = await Native.http(method, url, payload, timeout);
    if (!r || r.error) throw new Error((r && r.error) || 'Sem resposta');
  } else {
    const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const t = setTimeout(() => ctl && ctl.abort(), timeout);
    try {
      const res = await fetch(url, {
        method, cache: 'no-store', signal: ctl ? ctl.signal : undefined,
        body: method === 'GET' ? undefined : payload,
        headers: method === 'GET' ? undefined : { 'Content-Type': 'text/plain' }
      });
      r = { status: res.status, body: await res.text() };
    } catch (e) {
      throw new Error(e && e.name === 'AbortError' ? 'Tempo esgotado' : 'Sem conexão');
    } finally { clearTimeout(t); }
  }
  let j = null; try { j = JSON.parse(r.body); } catch (e) { j = null; }
  if (r.status === 401 || r.status === 403) { const e = new Error((j && j.error) || 'Não autorizado'); e.code = r.status; e.data = j; throw e; }
  if (r.status >= 400) { const e = new Error((j && j.error) || ('Erro ' + r.status)); e.code = r.status; throw e; }
  if (j == null) throw new Error('Resposta inválida');
  return j;
}

/* ---------------- cliente do OBS (obs-websocket 5.x) ---------------- */
async function obsAuthString(password, salt, challenge) {
  async function b64sha(str) {
    if (window.crypto && crypto.subtle && window.isSecureContext) {
      const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
      let s = ''; new Uint8Array(buf).forEach(b => s += String.fromCharCode(b));
      return btoa(s);
    }
    return sha256b64(str);
  }
  const secret = await b64sha(password + salt);
  return b64sha(secret + challenge);
}

class ObsClient extends Emitter {
  constructor() {
    super();
    this.ws = null; this.status = 'idle'; this.detail = '';
    this.pending = new Map(); this.seq = 0; this.retry = 0;
    this.wantMeters = false; this.url = ''; this.password = '';
  }
  setStatus(s, detail) {
    this.status = s; this.detail = detail || '';
    this.emit('status', s, this.detail);
  }
  connect(host, port, password) {
    this.disconnect(true);
    if (!host) { this.setStatus('idle'); return; }
    this.url = 'ws://' + host + ':' + (port || 4455);
    this.password = password || '';
    this.manual = false; this.retry = 0;
    this._open();
  }
  disconnect(silent) {
    this.manual = true; clearTimeout(this.rt); clearTimeout(this.ct);
    if (this.ws) { try { this.ws.close(); } catch (e) { } this.ws = null; }
    if (!silent) this.setStatus('idle');
  }
  reconnectNow() { if (this.url && this.status !== 'ready') { clearTimeout(this.rt); this.manual = false; this._open(); } }
  subs() { return 2047 | (this.wantMeters ? 65536 : 0); }
  setMeters(on) {
    if (this.wantMeters === on) return;
    this.wantMeters = on;
    if (this.status === 'ready') this._send(3, { eventSubscriptions: this.subs() });
  }
  _send(op, d) { if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify({ op, d })); }
  _open() {
    clearTimeout(this.rt); clearTimeout(this.ct);
    this.setStatus('connecting');
    let ws;
    try { ws = new WebSocket(this.url, 'obswebsocket.json'); }
    catch (e) { this.setStatus('error', 'Endereço inválido'); return; }
    this.ws = ws;
    ws.onmessage = ev => { let m; try { m = JSON.parse(ev.data); } catch (e) { return; } this._msg(m); };
    ws.onclose = ev => { if (this.ws === ws) this._closed(ev); };
    ws.onerror = () => { };
    this.ct = setTimeout(() => { if (this.ws === ws && this.status === 'connecting') { try { ws.close(); } catch (e) { } } }, 7000);
  }
  async _msg(m) {
    const d = m.d || {};
    if (m.op === 0) {
      const ident = { rpcVersion: 1, eventSubscriptions: this.subs() };
      if (d.authentication) {
        if (!this.password) { this.authProblem = 'need'; this.manual = true; try { this.ws.close(); } catch (e) { } this.setStatus('auth', 'O OBS pede senha'); return; }
        ident.authentication = await obsAuthString(this.password, d.authentication.salt, d.authentication.challenge);
      }
      this._send(1, ident);
    } else if (m.op === 2) {
      clearTimeout(this.ct); this.retry = 0;
      if (this.status === 'ready') return;   // resposta a um Reidentify (ex.: ligar medidores)
      this.setStatus('ready');
      this.emit('ready');
    } else if (m.op === 5) {
      this.emit('event', d.eventType, d.eventData || {});
    } else if (m.op === 7) {
      const p = this.pending.get(d.requestId);
      if (!p) return;
      this.pending.delete(d.requestId); clearTimeout(p.t);
      if (d.requestStatus && d.requestStatus.result) p.res(d.responseData || {});
      else { const e = new Error((d.requestStatus && d.requestStatus.comment) || 'Falhou'); e.code = d.requestStatus && d.requestStatus.code; p.rej(e); }
    }
  }
  _closed(ev) {
    clearTimeout(this.ct);
    this.ws = null;
    this.pending.forEach(p => { clearTimeout(p.t); p.rej(new Error('Desconectado')); });
    this.pending.clear();
    if (this.status === 'ready') this.emit('lost');
    if (ev && ev.code === 4009) { this.manual = true; this.setStatus('auth', 'Senha do OBS incorreta'); return; }
    if (this.manual) { if (this.status !== 'auth') this.setStatus('idle'); return; }
    const delay = Math.min(12000, Math.round(1200 * Math.pow(1.5, this.retry++)));
    this.setStatus('offline', 'OBS não respondeu');
    this.rt = setTimeout(() => this._open(), delay);
  }
  request(type, data, timeout) {
    return new Promise((res, rej) => {
      if (!this.ws || this.status !== 'ready') { rej(new Error('OBS desconectado')); return; }
      const id = 'r' + (++this.seq);
      const t = setTimeout(() => { this.pending.delete(id); rej(new Error('O OBS demorou para responder')); }, timeout || 8000);
      this.pending.set(id, { res, rej, t });
      this._send(6, { requestType: type, requestId: id, requestData: data || {} });
    });
  }
}

/* ---------------- cliente do Garra Hub (app do Windows) ---------------- */
class HubClient extends Emitter {
  constructor() {
    super();
    this.cfg = null; this.status = 'none'; this.state = null; this.fails = 0; this.fast = false; this.timer = 0;
  }
  setStatus(s) { if (this.status !== s) { this.status = s; this.emit('status', s); } }
  base(cfg) { cfg = cfg || this.cfg; return 'http://' + cfg.host + ':' + (cfg.port || APP.hubPort); }
  url(path, q, cfg) {
    cfg = cfg || this.cfg;
    const p = new URLSearchParams(q || {});
    if (cfg && cfg.token) p.set('t', cfg.token);
    const qs = p.toString();
    return this.base(cfg) + path + (qs ? '?' + qs : '');
  }
  configure(cfg) {
    clearTimeout(this.timer);
    this.cfg = cfg && cfg.host ? cfg : null;
    this.state = null; this.fails = 0;
    if (this.cfg) { this.setStatus('connecting'); this.poll(); } else this.setStatus('none');
  }
  setFast(on) { if (this.fast !== on) { this.fast = on; if (on && this.cfg) this.poll(); } }
  interval() { if (document.hidden) return 15000; return this.fast ? 1200 : 5000; }
  async poll() {
    clearTimeout(this.timer);
    if (!this.cfg) return;
    const cfg = this.cfg;
    try {
      const j = await httpJson('GET', this.url('/api/state'), null, 4500);
      if (cfg !== this.cfg) return;
      if (j && j.ok) { this.state = j; this.fails = 0; this.setStatus('ready'); this.emit('state', j); }
    } catch (e) {
      if (cfg !== this.cfg) return;
      if (e.code === 401 || e.code === 403) { this.setStatus('unpaired'); this.timer = setTimeout(() => this.poll(), 8000); return; }
      this.fails++;
      if (this.fails >= 2) this.setStatus('offline');
    }
    this.timer = setTimeout(() => this.poll(), this.status === 'offline' ? Math.min(15000, 3000 * this.fails) : this.interval());
  }
  async cmd(o) {
    if (!this.cfg) throw new Error('PC não conectado');
    const j = await httpJson('POST', this.url('/api/cmd'), o, 5000);
    if (!j.ok) throw new Error(j.error || 'Não deu certo');
    return j;
  }
  get(path, q) { return httpJson('GET', this.url(path, q), null, 6000); }
  imgUrl(path, q) { return this.url(path, q); }
  static hello(host, port) { return httpJson('GET', 'http://' + host + ':' + (port || APP.hubPort) + '/api/hello', null, 2500); }
  static pair(host, port, pin, device) {
    return httpJson('POST', 'http://' + host + ':' + (port || APP.hubPort) + '/api/pair', { pin, device }, 6000);
  }
}

/* ---------------- busca automática na rede ---------------- */
async function discover() {
  const out = { hubs: [], obs: [] };
  if (!Native) return out;
  const found = (await Native.scan([APP.hubPort, APP.obsPort], 500)) || [];
  const hubIps = found.filter(f => f.port === APP.hubPort).map(f => f.ip);
  const obsIps = found.filter(f => f.port === APP.obsPort).map(f => f.ip);
  const hellos = await Promise.all(hubIps.map(ip => HubClient.hello(ip, APP.hubPort).then(j => ({ ip, j })).catch(() => null)));
  hellos.forEach(x => { if (x && x.j && x.j.app === 'garra-hub') out.hubs.push({ host: x.ip, port: APP.hubPort, name: x.j.name || x.ip, version: x.j.v }); });
  out.obs = obsIps.map(ip => ({ host: ip, port: APP.obsPort, hasHub: hubIps.indexOf(ip) >= 0 }));
  return out;
}
