/* Garra — interface */
(function () {
'use strict';

const cfg = Cfg.load();
const $ = (s, r) => (r || document).querySelector(s);

/* ================= helpers de DOM ================= */
function h(tag, props) {
  const el = document.createElement(tag);
  if (props) for (const k in props) {
    const v = props[k];
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style') el.style.cssText = v;
    else if (k === 'html') el.innerHTML = v;
    else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (let i = 2; i < arguments.length; i++) add(el, arguments[i]);
  return el;
}
function add(el, c) {
  if (c == null || c === false) return;
  if (Array.isArray(c)) { c.forEach(x => add(el, x)); return; }
  el.append(c.nodeType ? c : document.createTextNode(String(c)));
}

const ICONS = {
  live: '<path d="M4.9 19.1C1 15.2 1 8.8 4.9 4.9"/><path d="M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5"/><circle cx="12" cy="12" r="2"/><path d="M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5"/><path d="M19.1 4.9C23 8.8 23 15.1 19.1 19"/>',
  sliders: '<line x1="4" x2="4" y1="21" y2="14"/><line x1="4" x2="4" y1="10" y2="3"/><line x1="12" x2="12" y1="21" y2="12"/><line x1="12" x2="12" y1="8" y2="3"/><line x1="20" x2="20" y1="21" y2="16"/><line x1="20" x2="20" y1="12" y2="3"/><line x1="2" x2="6" y1="14" y2="14"/><line x1="10" x2="14" y1="8" y2="8"/><line x1="18" x2="22" y1="16" y2="16"/>',
  pc: '<rect width="20" height="14" x="2" y="3" rx="2"/><line x1="8" x2="16" y1="21" y2="21"/><line x1="12" x2="12" y1="17" y2="21"/>',
  grid: '<rect width="7" height="7" x="3" y="3" rx="1.5"/><rect width="7" height="7" x="14" y="3" rx="1.5"/><rect width="7" height="7" x="14" y="14" rx="1.5"/><rect width="7" height="7" x="3" y="14" rx="1.5"/>',
  gear: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  mic: '<path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/>',
  micoff: '<line x1="2" x2="22" y1="2" y2="22"/><path d="M18.89 13.23A7.12 7.12 0 0 0 19 12v-2"/><path d="M5 10v2a7 7 0 0 0 12 5"/><path d="M15 9.34V5a3 3 0 0 0-5.68-1.33"/><path d="M9 9v3a3 3 0 0 0 5.12 2.12"/><line x1="12" x2="12" y1="19" y2="22"/>',
  vol: '<path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"/><path d="M16 9a5 5 0 0 1 0 6"/><path d="M19.364 18.364a9 9 0 0 0 0-12.728"/>',
  voloff: '<path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"/><line x1="22" x2="16" y1="9" y2="15"/><line x1="16" x2="22" y1="9" y2="15"/>',
  rec: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4" fill="currentColor"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/>',
  pause: '<rect x="6" y="5" width="4" height="14" rx="1" fill="currentColor"/><rect x="14" y="5" width="4" height="14" rx="1" fill="currentColor"/>',
  play: '<path d="M7 4.5v15a1 1 0 0 0 1.5.86l12-7.5a1 1 0 0 0 0-1.72l-12-7.5A1 1 0 0 0 7 4.5Z" fill="currentColor"/>',
  next: '<path d="M5 5v14l10-7Z" fill="currentColor"/><line x1="19" x2="19" y1="5" y2="19"/>',
  prev: '<path d="M19 5v14L9 12Z" fill="currentColor"/><line x1="5" x2="5" y1="5" y2="19"/>',
  replay: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>',
  vcam: '<path d="m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5"/><rect x="2" y="6" width="14" height="12" rx="2"/>',
  lock: '<rect width="18" height="11" x="3" y="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  screenoff: '<path d="M17 17H4a2 2 0 0 1-2-2V5c0-1.5 1-2 1-2"/><path d="M22 15V5a2 2 0 0 0-2-2H9"/><path d="M8 21h8"/><path d="M12 17v4"/><path d="m2 2 20 20"/>',
  camera: '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/>',
  aperture: '<circle cx="12" cy="12" r="10"/><path d="m14.31 8 5.74 9.94"/><path d="M9.69 8h11.48"/><path d="m7.38 12 5.74-9.94"/><path d="M9.69 16 3.95 6.06"/><path d="M14.31 16H2.83"/><path d="m16.62 12-5.74 9.94"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  right: '<path d="m9 18 6-6-6-6"/>',
  left: '<path d="m15 18-6-6 6-6"/>',
  down: '<path d="m6 9 6 6 6-6"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
  wifi: '<path d="M12 20h.01"/><path d="M2 8.82a15 15 0 0 1 20 0"/><path d="M5 12.859a10 10 0 0 1 14 0"/><path d="M8.5 16.429a5 5 0 0 1 7 0"/>',
  eye: '<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>',
  eyeoff: '<path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/><path d="m2 2 20 20"/>',
  layers: '<path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>',
  refresh: '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
  gamepad: '<line x1="6" x2="10" y1="11" y2="11"/><line x1="8" x2="8" y1="9" y2="13"/><line x1="15" x2="15.01" y1="12" y2="12"/><line x1="18" x2="18.01" y1="10" y2="10"/><path d="M17.32 5H6.68a4 4 0 0 0-3.978 3.59C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258A4 4 0 0 0 17.32 5z"/>',
  star: '<path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z"/>',
  moon: '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
  power: '<path d="M12 2v10"/><path d="M18.4 6.6a9 9 0 1 1-12.77.04"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
  headphones: '<path d="M3 14h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a9 9 0 0 1 18 0v7a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3"/>',
  music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
  swap: '<path d="M8 3 4 7l4 4"/><path d="M4 7h16"/><path d="m16 21 4-4-4-4"/><path d="M20 17H4"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
  trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
  alert: '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
  ext: '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
  sparkles: '<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/>',
  keypad: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8"/><path d="M8 10h.01"/><path d="M12 10h.01"/><path d="M16 10h.01"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/><path d="M8 18h8"/>'
};
function ic(name, cls) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'ic' + (cls ? ' ' + cls : ''));
  s.setAttribute('aria-hidden', 'true');
  s.innerHTML = ICONS[name] || '';
  return s;
}
const MARK_D = 'M8.6 6.0 L8.5 5.6 L8.6 5.3 L8.7 5.0 L8.8 4.7 L8.9 4.5 L9.1 4.3 L9.3 4.1 L9.4 3.9 L9.6 3.7 L9.8 3.5 L10.0 3.4 L10.2 3.3 L10.5 3.1 L10.7 3.0 L10.9 2.9 L11.2 2.9 L11.4 2.8 L11.7 2.8 L11.9 2.7 L12.2 2.7 L12.4 2.7 L12.7 2.8 L12.9 2.8 L13.2 2.8 L13.4 2.9 L13.7 3.0 L13.9 3.1 L14.1 3.2 L14.3 3.4 L14.5 3.5 L14.7 3.7 L14.9 3.9 L15.1 4.1 L15.3 4.3 L15.4 4.5 L15.5 4.8 L15.5 4.9 L15.2 4.9 L15.0 4.9 L14.7 5.0 L14.5 5.0 L14.3 5.0 L14.1 5.0 L13.9 5.1 L13.7 5.1 L13.5 5.2 L13.2 5.2 L13.1 5.3 L12.9 5.3 L12.7 5.4 L12.5 5.5 L12.3 5.5 L12.1 5.6 L12.0 5.7 L11.8 5.7 L11.6 5.8 L11.5 5.9 L11.3 5.9 L11.1 6.0 L11.0 6.0 L10.8 6.1 L10.7 6.1 L10.5 6.2 L10.3 6.2 L10.2 6.2 L10.0 6.3 L9.8 6.3 L9.7 6.3 L9.5 6.3 L9.3 6.3 L9.1 6.3 L8.9 6.2 L8.6 6.1 Z M17.8 6.4 L18.1 6.3 L18.4 6.3 L18.6 6.4 L18.8 6.4 L19.1 6.5 L19.2 6.6 L19.4 6.7 L19.6 6.8 L19.7 7.0 L19.9 7.1 L20.0 7.3 L20.1 7.5 L20.2 7.6 L20.3 7.8 L20.3 8.0 L20.4 8.2 L20.4 8.4 L20.5 8.6 L20.5 8.8 L20.5 9.0 L20.5 9.2 L20.5 9.4 L20.5 9.6 L20.4 9.8 L20.4 10.0 L20.3 10.2 L20.3 10.4 L20.2 10.6 L20.1 10.8 L20.0 11.0 L19.9 11.1 L19.8 11.3 L19.7 11.5 L19.6 11.7 L19.4 11.8 L19.2 12.0 L19.2 12.0 L19.1 11.8 L19.0 11.7 L18.9 11.6 L18.8 11.4 L18.8 11.3 L18.7 11.1 L18.7 11.0 L18.6 10.9 L18.5 10.7 L18.5 10.6 L18.4 10.5 L18.4 10.3 L18.4 10.2 L18.3 10.1 L18.3 9.9 L18.2 9.8 L18.2 9.6 L18.2 9.5 L18.1 9.4 L18.1 9.2 L18.1 9.1 L18.1 8.9 L18.0 8.8 L18.0 8.6 L18.0 8.5 L17.9 8.3 L17.9 8.2 L17.9 8.0 L17.8 7.8 L17.8 7.7 L17.8 7.5 L17.8 7.3 L17.7 7.1 L17.7 6.9 L17.7 6.7 L17.7 6.5 Z M18.7 13.9 L19.1 14.2 L19.2 14.5 L19.4 14.7 L19.5 15.0 L19.6 15.2 L19.6 15.5 L19.6 15.7 L19.7 16.0 L19.6 16.2 L19.6 16.5 L19.6 16.7 L19.5 17.0 L19.5 17.2 L19.4 17.4 L19.3 17.6 L19.2 17.8 L19.0 18.0 L18.9 18.2 L18.7 18.4 L18.6 18.5 L18.4 18.7 L18.2 18.8 L18.0 19.0 L17.8 19.1 L17.6 19.2 L17.4 19.3 L17.1 19.4 L16.9 19.4 L16.7 19.5 L16.4 19.5 L16.2 19.5 L15.9 19.5 L15.7 19.5 L15.4 19.4 L15.2 19.3 L14.9 19.1 L14.9 19.1 L15.0 18.9 L15.1 18.7 L15.2 18.5 L15.3 18.3 L15.5 18.2 L15.6 18.0 L15.7 17.8 L15.8 17.7 L15.8 17.5 L15.9 17.3 L16.0 17.2 L16.1 17.0 L16.2 16.8 L16.3 16.7 L16.3 16.5 L16.4 16.4 L16.5 16.2 L16.5 16.1 L16.6 15.9 L16.7 15.8 L16.7 15.7 L16.8 15.5 L16.9 15.4 L17.0 15.3 L17.0 15.1 L17.1 15.0 L17.2 14.9 L17.3 14.8 L17.4 14.7 L17.5 14.5 L17.7 14.4 L17.8 14.3 L18.0 14.2 L18.1 14.1 L18.3 14.0 L18.6 13.9 Z M12.0 19.8 L11.8 20.2 L11.6 20.4 L11.4 20.6 L11.2 20.7 L11.0 20.8 L10.8 20.9 L10.5 20.9 L10.3 21.0 L10.1 21.0 L9.9 21.0 L9.7 20.9 L9.4 20.9 L9.2 20.9 L9.0 20.8 L8.8 20.7 L8.6 20.6 L8.5 20.5 L8.3 20.4 L8.1 20.2 L7.9 20.1 L7.8 19.9 L7.6 19.8 L7.5 19.6 L7.4 19.4 L7.2 19.2 L7.1 19.0 L7.0 18.8 L6.9 18.6 L6.9 18.4 L6.8 18.2 L6.7 18.0 L6.7 17.8 L6.6 17.6 L6.6 17.3 L6.6 17.1 L6.6 16.8 L6.7 16.8 L6.9 16.8 L7.1 16.9 L7.2 16.9 L7.4 17.0 L7.6 17.0 L7.7 17.1 L7.9 17.2 L8.0 17.2 L8.2 17.3 L8.3 17.4 L8.4 17.4 L8.6 17.5 L8.7 17.6 L8.8 17.6 L9.0 17.7 L9.1 17.8 L9.2 17.8 L9.4 17.9 L9.5 18.0 L9.6 18.1 L9.8 18.2 L9.9 18.2 L10.0 18.3 L10.2 18.4 L10.3 18.5 L10.4 18.6 L10.6 18.7 L10.7 18.8 L10.9 18.9 L11.0 19.0 L11.2 19.1 L11.3 19.2 L11.5 19.3 L11.7 19.4 L11.8 19.6 L12.0 19.8 Z M5.8 14.6 L5.3 14.6 L5.0 14.6 L4.8 14.5 L4.6 14.3 L4.4 14.2 L4.2 14.0 L4.0 13.9 L3.9 13.7 L3.7 13.5 L3.6 13.3 L3.5 13.2 L3.4 13.0 L3.3 12.8 L3.2 12.5 L3.1 12.3 L3.1 12.1 L3.0 11.9 L3.0 11.7 L3.0 11.5 L3.0 11.3 L3.1 11.0 L3.1 10.8 L3.1 10.6 L3.2 10.4 L3.3 10.2 L3.4 10.0 L3.5 9.8 L3.6 9.6 L3.7 9.4 L3.9 9.3 L4.0 9.1 L4.2 8.9 L4.4 8.8 L4.6 8.7 L4.9 8.6 L5.1 8.5 L5.2 8.5 L5.2 8.8 L5.3 9.0 L5.3 9.2 L5.3 9.4 L5.3 9.6 L5.4 9.8 L5.4 9.9 L5.4 10.1 L5.5 10.3 L5.5 10.5 L5.6 10.7 L5.6 10.8 L5.6 11.0 L5.7 11.2 L5.7 11.3 L5.8 11.5 L5.8 11.6 L5.9 11.8 L5.9 11.9 L6.0 12.1 L6.0 12.2 L6.1 12.4 L6.1 12.5 L6.1 12.7 L6.1 12.8 L6.2 12.9 L6.2 13.1 L6.2 13.2 L6.2 13.4 L6.2 13.5 L6.2 13.7 L6.1 13.8 L6.1 14.0 L6.1 14.2 L6.0 14.4 L5.8 14.6 Z M12.0 12.1 L11.8 12.3 L11.5 12.4 L11.1 12.5 L10.8 12.4 L10.5 12.2 L10.2 12.0 L10.0 11.7 L9.8 11.5 L9.7 11.2 L9.7 10.9 L9.7 10.6 L9.8 10.3 L10.0 10.1 L10.3 10.0 L10.7 9.9 L11.0 10.0 L11.3 10.2 L11.6 10.4 L11.8 10.7 L12.0 10.9 L12.1 11.2 L12.1 11.5 L12.1 11.8 Z M14.4 11.2 L14.5 11.4 L14.5 11.7 L14.5 11.9 L14.3 12.1 L14.2 12.3 L13.9 12.5 L13.7 12.5 L13.4 12.6 L13.2 12.5 L13.0 12.4 L12.8 12.3 L12.6 12.2 L12.5 12.0 L12.5 11.7 L12.5 11.5 L12.7 11.3 L12.8 11.1 L13.1 10.9 L13.3 10.9 L13.6 10.8 L13.8 10.9 L14.0 11.0 L14.2 11.1 Z M12.9 14.2 L12.9 14.4 L12.8 14.6 L12.6 14.7 L12.4 14.8 L12.2 14.8 L11.9 14.7 L11.8 14.7 L11.6 14.5 L11.4 14.4 L11.3 14.2 L11.3 14.0 L11.3 13.8 L11.3 13.6 L11.4 13.4 L11.6 13.3 L11.8 13.2 L12.0 13.2 L12.3 13.3 L12.4 13.3 L12.6 13.5 L12.8 13.6 L12.9 13.8 L12.9 14.0 Z';
function mark(cls) {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'mark' + (cls ? ' ' + cls : ''));
  s.innerHTML = '<path d="' + MARK_D + '" fill="currentColor"/>';
  return s;
}

/* ================= feedback ================= */
function haptic(kind) {
  if (!cfg.prefs.haptics) return;
  if (Native) Native.haptic(kind || 'tap');
  else if (navigator.vibrate) { try { navigator.vibrate(kind === 'confirm' ? [12, 40, 12] : kind === 'reject' ? [30, 30, 30] : 8); } catch (e) { } }
}
let toastTimer = 0;
function toast(msg, kind) {
  let t = $('#toast');
  if (!t) { t = h('div', { id: 'toast', role: 'status', 'aria-live': 'polite' }); document.body.append(t); }
  t.className = 'toast show ' + (kind || '');
  t.textContent = msg;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.className = 'toast ' + (kind || ''); }, 2600);
}
function fail(e, prefix) { haptic('reject'); toast((prefix ? prefix + ': ' : '') + (e && e.message ? e.message : e), 'bad'); }

/* ================= camadas (folhas, páginas) e botão voltar ================= */
const layers = [];
function pushLayer(close) { layers.push(close); }
function dropLayer(close) { const i = layers.lastIndexOf(close); if (i >= 0) layers.splice(i, 1); }
window.garraBack = function () {
  if (layers.length) { layers[layers.length - 1](); return true; }
  if (S.tab !== homeTab()) { setTab(homeTab()); return true; }
  return false;
};
document.addEventListener('keydown', e => { if (e.key === 'Escape') window.garraBack(); });

function sheet(opts) {
  const back = h('div', { class: 'backdrop' });
  const box = h('div', { class: 'sheet' + (opts.cls ? ' ' + opts.cls : ''), role: 'dialog', 'aria-modal': 'true' },
    h('div', { class: 'grab' }),
    opts.title ? h('div', { class: 'sheet-head' }, h('h3', null, opts.title), opts.sub ? h('p', null, opts.sub) : null) : null,
    h('div', { class: 'sheet-body' }, opts.body)
  );
  const close = () => {
    dropLayer(close);
    back.classList.remove('in'); box.classList.remove('in');
    setTimeout(() => { back.remove(); box.remove(); }, 220);
    if (opts.onClose) opts.onClose();
  };
  back.addEventListener('click', close);
  // arrastar para baixo para fechar
  let y0 = null, dy = 0;
  box.addEventListener('touchstart', e => { if (box.scrollTop <= 0 && e.target.closest('.grab,.sheet-head')) { y0 = e.touches[0].clientY; dy = 0; } }, { passive: true });
  box.addEventListener('touchmove', e => { if (y0 == null) return; dy = Math.max(0, e.touches[0].clientY - y0); box.style.transform = 'translateY(' + dy + 'px)'; }, { passive: true });
  box.addEventListener('touchend', () => { if (y0 == null) return; box.style.transform = ''; if (dy > 90) close(); y0 = null; });
  document.body.append(back, box);
  requestAnimationFrame(() => { back.classList.add('in'); box.classList.add('in'); });
  pushLayer(close);
  return { el: box, close };
}
function confirmSheet(o) {
  let s;
  const ok = h('button', { class: 'btn ' + (o.okClass || 'primary') + ' block', onclick: () => { s.close(); o.onOk(); } }, o.ok || 'Confirmar');
  s = sheet({
    title: o.title, sub: o.text,
    body: h('div', { class: 'stack' }, ok, h('button', { class: 'btn ghost block', onclick: () => s.close() }, o.cancel || 'Cancelar'))
  });
  return s;
}

/* ================= componentes ================= */
const p2mul = p => p <= 0 ? 0 : Math.pow(p, 3);
const mul2p = m => m <= 0 ? 0 : Math.min(1, Math.cbrt(m));
const fmtDb = m => m <= 0.00002 ? '−∞ dB' : (20 * Math.log10(m)).toFixed(1).replace('-', '−').replace('.', ',') + ' dB';
const pct = v => Math.round(v * 100) + '%';
function fmtTime(ms) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const hh = Math.floor(s / 3600), mm = Math.floor(s / 60) % 60, ss = s % 60;
  return (hh ? hh + ':' : '') + String(mm).padStart(hh ? 2 : 1, '0') + ':' + String(ss).padStart(2, '0');
}
function throttle(fn, ms) {
  let last = 0, timer = 0, lastArgs;
  return function () {
    lastArgs = arguments;
    const now = Date.now(), wait = ms - (now - last);
    if (wait <= 0) { last = now; fn.apply(null, lastArgs); }
    else { clearTimeout(timer); timer = setTimeout(() => { last = Date.now(); fn.apply(null, lastArgs); }, wait); }
  };
}

function Slider(o) {
  const input = h('input', { type: 'range', min: 0, max: 1000, step: 1, 'aria-label': o.label || 'Volume' });
  const wrap = h('div', { class: 'slider' }, input);
  let touched = 0, lastSent = -1;
  const paint = () => wrap.style.setProperty('--p', (input.value / 1000).toFixed(4));
  const emit = (p, fin) => { if (p === lastSent) return; lastSent = p; o.onChange(p, fin); };
  const send = throttle(p => emit(p, false), 90);
  input.addEventListener('input', () => { touched = Date.now(); paint(); const p = input.value / 1000; if (o.onLive) o.onLive(p); send(p); });
  input.addEventListener('change', () => { touched = Date.now(); setTimeout(() => emit(input.value / 1000, true), 100); });
  wrap.set = p => { if (Date.now() - touched < 900) return; input.value = Math.round(p * 1000); paint(); };
  wrap.disable = d => { input.disabled = !!d; wrap.classList.toggle('off', !!d); };
  return wrap;
}
function Switch(onChange, label) {
  const b = h('button', { class: 'switch', role: 'switch', 'aria-checked': 'false', 'aria-label': label || '' }, h('span'));
  b.addEventListener('click', e => { e.stopPropagation(); const v = b.getAttribute('aria-checked') !== 'true'; b.set(v); haptic('tap'); onChange(v); });
  b.set = v => b.setAttribute('aria-checked', v ? 'true' : 'false');
  return b;
}
function HoldButton(label, onDone, cls, iconName) {
  const lbl = h('span', { class: 'lbl' }, iconName ? ic(iconName) : null, h('span', null, label));
  const b = h('button', { class: 'btn hold ' + (cls || '') }, h('span', { class: 'fill' }), lbl);
  let t0 = 0, raf = 0, done = false, active = false;
  const DUR = 900;
  const end = () => { active = false; cancelAnimationFrame(raf); b.classList.remove('holding'); b.style.setProperty('--hp', 0); };
  b.addEventListener('pointerdown', e => {
    if (e.button && e.button !== 0) return;
    done = false; active = true; t0 = performance.now(); b.classList.add('holding'); haptic('tap');
    try { b.setPointerCapture(e.pointerId); } catch (x) { }
    const step = () => {
      if (!active) return;
      const p = Math.min(1, (performance.now() - t0) / DUR);
      b.style.setProperty('--hp', p);
      if (p >= 1) { done = true; end(); haptic('confirm'); onDone(); return; }
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
  });
  const cancel = () => { if (!active) return; if (!done && performance.now() - t0 < 350) toast('Segure o botão para confirmar'); end(); };
  b.addEventListener('pointerup', cancel); b.addEventListener('pointercancel', cancel); b.addEventListener('lostpointercapture', cancel);
  b.addEventListener('contextmenu', e => e.preventDefault());
  b.setLabel = t => { lbl.lastChild.textContent = t; };
  return b;
}
function listSync(box, items, keyFn, create, update) {
  const old = box._map || new Map(), next = new Map();
  items.forEach((it, i) => {
    const k = keyFn(it);
    let el = old.get(k);
    if (!el) el = create(it);
    update(el, it);
    next.set(k, el);
    if (box.children[i] !== el) box.insertBefore(el, box.children[i] || null);
  });
  old.forEach((el, k) => { if (!next.has(k)) el.remove(); });
  box._map = next;
}
function avatar(name, cls) {
  const letters = (name || '?').replace(/[^\p{L}\p{N} ]/gu, '').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() || '?';
  let hsh = 0; for (const c of name || '') hsh = (hsh * 31 + c.charCodeAt(0)) | 0;
  const hue = [28, 36, 18, 44, 12, 200, 160, 280][Math.abs(hsh) % 8];
  return h('span', { class: 'avatar ' + (cls || ''), style: '--h:' + hue }, letters);
}
function emptyState(iconName, title, text, actions) {
  return h('div', { class: 'empty' }, h('div', { class: 'empty-ic' }, ic(iconName)), h('h4', null, title), text ? h('p', null, text) : null, actions ? h('div', { class: 'row-actions' }, actions) : null);
}
function sectionHead(title, extra) { return h('div', { class: 'sec-head' }, h('h2', null, title), extra || null); }

/* ================= estado ================= */
const S = { tab: 'live', demo: false, hubOrigin: null, launchers: null, lfilter: 'all', lsearch: '' };
const realObs = new ObsClient(), realHub = new HubClient();
let obs = realObs, hub = realHub;
let M = freshModel();
function freshModel() {
  return {
    scenes: [], program: '', preview: '', studio: false,
    stream: { active: false, reconnecting: false, ms: 0, at: 0, bytes: 0, kbps: 0, lastBytes: 0, lastAt: 0, cong: 0 },
    rec: { active: false, paused: false, ms: 0, at: 0 },
    replay: { avail: false, active: false }, vcam: { avail: false, active: false },
    stats: null, inputs: [], items: [], itemsScene: '', mic: '', special: {}, meters: {}, loaded: false
  };
}
const req = (t, d) => obs.request(t, d);

/* ================= OBS: carregar e manter atualizado ================= */
async function obsLoad() {
  M = freshModel();
  try {
    const [sl, sm] = await Promise.all([req('GetSceneList'), req('GetStudioModeEnabled').catch(() => ({ studioModeEnabled: false }))]);
    M.scenes = (sl.scenes || []).slice().sort((a, b) => b.sceneIndex - a.sceneIndex).map(s => s.sceneName);
    M.program = sl.currentProgramSceneName || '';
    M.studio = !!sm.studioModeEnabled;
    M.preview = M.studio ? (sl.currentPreviewSceneName || '') : '';
    await Promise.all([refreshOutputs(true), loadInputs(), loadItems(), refreshStats()]);
    M.loaded = true;
  } catch (e) { console.warn(e); }
  renderAll();
}
async function refreshOutputs(all) {
  const tasks = [];
  if (all || M.stream.active) tasks.push(req('GetStreamStatus').then(r => {
    const now = Date.now();
    M.stream.active = !!r.outputActive; M.stream.reconnecting = !!r.outputReconnecting;
    M.stream.ms = r.outputDuration || 0; M.stream.at = now; M.stream.cong = r.outputCongestion || 0;
    M.stream.skipped = r.outputSkippedFrames || 0; M.stream.total = r.outputTotalFrames || 0;
    if (M.stream.lastAt && r.outputBytes >= M.stream.lastBytes) M.stream.kbps = Math.round((r.outputBytes - M.stream.lastBytes) * 8 / Math.max(0.5, (now - M.stream.lastAt) / 1000) / 1000);
    M.stream.lastBytes = r.outputBytes || 0; M.stream.lastAt = now;
    if (!M.stream.active) { M.stream.kbps = 0; M.stream.lastAt = 0; }
  }).catch(() => { }));
  if (all || M.rec.active) tasks.push(req('GetRecordStatus').then(r => { M.rec.active = !!r.outputActive; M.rec.paused = !!r.outputPaused; M.rec.ms = r.outputDuration || 0; M.rec.at = Date.now(); }).catch(() => { }));
  if (all) {
    tasks.push(req('GetReplayBufferStatus').then(r => { M.replay.avail = true; M.replay.active = !!r.outputActive; }).catch(() => { M.replay.avail = false; }));
    tasks.push(req('GetVirtualCamStatus').then(r => { M.vcam.avail = true; M.vcam.active = !!r.outputActive; }).catch(() => { M.vcam.avail = false; }));
  }
  await Promise.all(tasks);
}
async function refreshStats() { try { M.stats = await req('GetStats'); } catch (e) { } }
async function loadInputs() {
  try {
    const [{ inputs }, special] = await Promise.all([req('GetInputList'), req('GetSpecialInputs').catch(() => ({}))]);
    const res = await Promise.all(inputs.map(async i => {
      try {
        const [v, m] = await Promise.all([req('GetInputVolume', { inputName: i.inputName }), req('GetInputMute', { inputName: i.inputName })]);
        return { name: i.inputName, kind: i.inputKind || '', mul: v.inputVolumeMul, muted: !!m.inputMuted };
      } catch (e) { return null; }
    }));
    M.special = special || {};
    const order = ['desktop1', 'desktop2', 'mic1', 'mic2', 'mic3', 'mic4'].map(k => M.special[k]).filter(Boolean);
    M.inputs = res.filter(Boolean).sort((a, b) => {
      const ia = order.indexOf(a.name), ib = order.indexOf(b.name);
      return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
    });
    pickMic();
  } catch (e) { console.warn(e); }
}
function pickMic() {
  const names = M.inputs.map(i => i.name);
  if (cfg.prefs.mic && names.indexOf(cfg.prefs.mic) >= 0) M.mic = cfg.prefs.mic;
  else if (M.special.mic1 && names.indexOf(M.special.mic1) >= 0) M.mic = M.special.mic1;
  else { const m = M.inputs.find(i => /input_capture|mic/i.test(i.kind) || /mic/i.test(i.name)); M.mic = m ? m.name : ''; }
}
async function loadItems() {
  const scene = M.studio && M.preview ? M.preview : M.program;
  if (!scene) { M.items = []; M.itemsScene = ''; return; }
  try {
    const r = await req('GetSceneItemList', { sceneName: scene });
    M.items = (r.sceneItems || []).slice().sort((a, b) => b.sceneItemIndex - a.sceneItemIndex)
      .map(i => ({ id: i.sceneItemId, name: i.sourceName, on: !!i.sceneItemEnabled, group: !!i.isGroup }));
    M.itemsScene = scene;
  } catch (e) { M.items = []; M.itemsScene = scene; }
}
let reloadT = {};
function later(key, fn, ms) { clearTimeout(reloadT[key]); reloadT[key] = setTimeout(fn, ms || 250); }

function onObsEvent(type, d) {
  switch (type) {
    case 'CurrentProgramSceneChanged': M.program = d.sceneName; if (!M.studio) later('items', () => loadItems().then(renderLive), 60); renderLive(); break;
    case 'CurrentPreviewSceneChanged': M.preview = d.sceneName; if (M.studio) later('items', () => loadItems().then(renderLive), 60); renderLive(); break;
    case 'StudioModeStateChanged': M.studio = !!d.studioModeEnabled;
      later('studio', async () => { if (M.studio) { try { M.preview = (await req('GetCurrentPreviewScene')).currentPreviewSceneName || ''; } catch (e) { } } else M.preview = ''; await loadItems(); renderLive(); }, 50); break;
    case 'SceneListChanged': M.scenes = (d.scenes || []).slice().sort((a, b) => b.sceneIndex - a.sceneIndex).map(s => s.sceneName); renderLive(); break;
    case 'SceneNameChanged': case 'SceneCreated': case 'SceneRemoved':
      later('scenes', async () => { try { const sl = await req('GetSceneList'); M.scenes = sl.scenes.slice().sort((a, b) => b.sceneIndex - a.sceneIndex).map(s => s.sceneName); M.program = sl.currentProgramSceneName; } catch (e) { } renderLive(); }); break;
    case 'StreamStateChanged': {
      const st = d.outputState || '';
      M.stream.active = !!d.outputActive; M.stream.reconnecting = /RECONNECTING$/.test(st);
      if (/STARTED$/.test(st)) { M.stream.ms = 0; M.stream.at = Date.now(); M.stream.lastAt = 0; toast('Você está ao vivo', 'good'); haptic('confirm'); }
      if (/STOPPED$/.test(st)) { toast('Transmissão encerrada'); M.stream.kbps = 0; }
      if (/RECONNECTING$/.test(st)) toast('Conexão da live instável — reconectando…', 'warn');
      renderLive(); break;
    }
    case 'RecordStateChanged': {
      const st = d.outputState || '';
      M.rec.active = !!d.outputActive;
      if (/STARTED$/.test(st)) { M.rec.ms = 0; M.rec.at = Date.now(); M.rec.paused = false; toast('Gravando', 'good'); }
      if (/PAUSED$/.test(st)) { M.rec.ms += Date.now() - M.rec.at; M.rec.at = Date.now(); M.rec.paused = true; }
      if (/RESUMED$/.test(st)) { M.rec.at = Date.now(); M.rec.paused = false; }
      if (/STOPPED$/.test(st)) { M.rec.paused = false; toast('Gravação salva'); }
      renderLive(); break;
    }
    case 'ReplayBufferStateChanged': M.replay.avail = true; M.replay.active = !!d.outputActive; renderLive(); break;
    case 'ReplayBufferSaved': toast('Replay salvo', 'good'); haptic('confirm'); break;
    case 'VirtualcamStateChanged': M.vcam.avail = true; M.vcam.active = !!d.outputActive; renderLive(); break;
    case 'InputMuteStateChanged': { const i = M.inputs.find(x => x.name === d.inputName); if (i) { i.muted = !!d.inputMuted; renderAudio(); renderLive(); } break; }
    case 'InputVolumeChanged': { const i = M.inputs.find(x => x.name === d.inputName); if (i) { i.mul = d.inputVolumeMul; renderAudio(); } break; }
    case 'InputCreated': case 'InputRemoved': case 'InputNameChanged':
      later('inputs', () => loadInputs().then(() => { renderAudio(); renderLive(); }), 400); break;
    case 'SceneItemEnableStateChanged':
      if (d.sceneName === M.itemsScene) { const it = M.items.find(x => x.id === d.sceneItemId); if (it) { it.on = !!d.sceneItemEnabled; renderLive(); } } break;
    case 'SceneItemCreated': case 'SceneItemRemoved': case 'SceneItemListReindexed':
      if (d.sceneName === M.itemsScene) later('items', () => loadItems().then(renderLive), 200); break;
    case 'InputVolumeMeters':
      (d.inputs || []).forEach(x => { let pk = 0; (x.inputLevelsMul || []).forEach(ch => { if (ch[1] > pk) pk = ch[1]; }); M.meters[x.inputName] = pk; });
      scheduleMeters(); break;
    case 'ExitStarted': toast('O OBS foi fechado no PC', 'warn'); break;
  }
}

let pollIv = 0;
function startObsPolling() {
  clearInterval(pollIv);
  pollIv = setInterval(async () => {
    if (obs.status !== 'ready' || document.hidden) return;
    await Promise.all([refreshOutputs(false), refreshStats()]);
    renderStats(); renderLive();
  }, 2000);
}

/* ================= ações do OBS ================= */
function act(promise, okMsg) { return promise.then(r => { if (okMsg) toast(okMsg, 'good'); return r; }).catch(e => fail(e)); }
function startStream() {
  const go = () => act(req('StartStream'));
  if (cfg.prefs.confirmStop) confirmSheet({ title: 'Começar a transmitir?', text: 'A cena atual (' + (M.program || '—') + ') vai ao ar agora.', ok: 'Ir ao vivo', onOk: go });
  else go();
}
function stopStream() { act(req('StopStream')); }
function toggleRec() { haptic('tap'); act(req(M.rec.active ? 'StopRecord' : 'StartRecord')); }
function pauseRec() { haptic('tap'); act(req(M.rec.paused ? 'ResumeRecord' : 'PauseRecord')); }
function replayAction() { haptic('tap'); act(req(M.replay.active ? 'SaveReplayBuffer' : 'StartReplayBuffer'), M.replay.active ? null : 'Replay ativado'); }
function toggleVcam() { haptic('tap'); act(req('ToggleVirtualCam')); }
function toggleMic() {
  if (!M.mic) { toast('Escolha o microfone em Ajustes'); return; }
  const i = M.inputs.find(x => x.name === M.mic);
  haptic(i && !i.muted ? 'reject' : 'confirm');
  act(req('ToggleInputMute', { inputName: M.mic }));
}
function pickScene(name) {
  haptic('tap');
  if (M.studio) { M.preview = name; renderLive(); act(req('SetCurrentPreviewScene', { sceneName: name })); }
  else { M.program = name; renderLive(); act(req('SetCurrentProgramScene', { sceneName: name })); }
}
function transition() { haptic('confirm'); act(req('TriggerStudioModeTransition')); }

/* ================= estrutura da tela ================= */
let ui = {};
function buildShell() {
  const root = $('#app'); root.innerHTML = '';
  ui.pillObs = h('button', { class: 'pill', onclick: () => obsHidden() ? addObsSheet() : connSheet('obs') }, h('i'), h('span', null, 'OBS'));
  ui.pillPc = h('button', { class: 'pill', onclick: () => connSheet('pc') }, h('i'), h('span', null, 'PC'));
  ui.header = h('header', { class: 'appbar' },
    h('div', { class: 'brand' }, mark(), h('span', { class: 'word' }, 'garra')),
    h('div', { class: 'grow' }),
    ui.pillObs, ui.pillPc,
    h('button', { class: 'iconbtn', 'aria-label': 'Ajustes', onclick: openSettings }, ic('gear'))
  );
  ui.onair = h('div', { class: 'onair' });
  ui.demoBar = h('div', { class: 'demobar' }, ic('sparkles'), h('span', null, 'Modo demonstração — nada aqui controla seu PC'), h('button', { onclick: () => setDemo(false) }, 'Sair'));
  ui.views = {
    live: h('section', { class: 'view', id: 'v-live' }),
    audio: h('section', { class: 'view', id: 'v-audio' }),
    pc: h('section', { class: 'view', id: 'v-pc' }),
    apps: h('section', { class: 'view', id: 'v-apps' })
  };
  ui.main = h('main', { class: 'main' }, ui.views.live, ui.views.audio, ui.views.pc, ui.views.apps);
  const tabs = [['live', 'live', 'Live'], ['audio', 'sliders', 'Áudio'], ['pc', 'pc', 'PC'], ['apps', 'grid', 'Atalhos']];
  ui.tabs = {};
  ui.tabbar = h('nav', { class: 'tabbar', role: 'tablist' }, tabs.map(t => ui.tabs[t[0]] = h('button', { role: 'tab', class: 'tab', onclick: () => { haptic('tap'); setTab(t[0]); } }, ic(t[1]), h('span', null, t[2]))));
  root.append(ui.header, ui.demoBar, ui.onair, ui.main, ui.tabbar);
  buildLive(); buildAudio(); buildPc(); buildApps();
  setTab(S.tab);
}
function setTab(t) {
  S.tab = t; document.body.dataset.tab = t;
  Object.keys(ui.views).forEach(k => { ui.views[k].classList.toggle('on', k === t); ui.tabs[k].classList.toggle('on', k === t); ui.tabs[k].setAttribute('aria-selected', k === t ? 'true' : 'false'); });
  hub.setFast(t === 'pc');
  obs.setMeters && obs.setMeters(t === 'audio' && cfg.prefs.meters);
  if (t === 'apps') loadLaunchers(false);
  ui.main.scrollTop = 0; window.scrollTo(0, 0);
}
function renderAll() { renderPills(); renderLive(); renderAudio(); renderPc(); renderApps(); renderStats(); }
function statusOf(kind) {
  if (kind === 'obs') {
    const s = obs.status;
    if (s === 'ready') return ['ok', 'Conectado'];
    if (s === 'connecting') return ['wait', 'Conectando…'];
    if (s === 'auth') return ['bad', obs.detail || 'Senha do OBS'];
    if (s === 'offline' || s === 'error') return ['bad', obs.detail || 'Sem conexão'];
    return ['off', 'Não configurado'];
  }
  const s = hub.status;
  if (s === 'ready') return ['ok', 'Conectado'];
  if (s === 'connecting') return ['wait', 'Conectando…'];
  if (s === 'unpaired') return ['bad', 'Precisa parear de novo'];
  if (s === 'offline') return ['bad', 'PC fora do ar'];
  return ['off', 'Não configurado'];
}
/* ---------- OBS opcional: quem usa só o controle do Windows não vê as abas do OBS ---------- */
function obsHidden() {
  if (S.demo) return false;
  if (cfg.useObs === true) return false;
  if (cfg.useObs === false) return true;
  return !cfg.obsSeen && obs.status !== 'ready';   // automático: some até o OBS conectar pela 1ª vez
}
function homeTab() { return obsHidden() ? 'pc' : 'live'; }
function applyObsVisibility() {
  const hide = obsHidden();
  document.body.classList.toggle('no-obs', hide);
  ['live', 'audio'].forEach(k => { if (ui.tabs && ui.tabs[k]) ui.tabs[k].hidden = hide; });
  ui.pillObs.classList.toggle('add', hide);
  ui.pillObs.querySelector('span').textContent = hide ? '+ OBS' : 'OBS';
  if (hide && (S.tab === 'live' || S.tab === 'audio')) setTab('pc');
}
function addObsSheet() {
  let s;
  s = sheet({
    title: 'Usar o Garra com o OBS?', sub: 'Liga as abas Live e Áudio: cenas, transmissão, gravação, replay e mixer do OBS.',
    body: h('div', { class: 'stack' },
      h('button', { class: 'btn primary block', onclick: () => { s.close(); cfg.useObs = true; Cfg.save(); renderAll(); startFlow(cfg.hub ? 'obs' : 'pc'); } }, ic('aperture'), 'Conectar ao OBS'),
      h('button', { class: 'btn ghost block', onclick: () => s.close() }, 'Agora não'))
  });
}
function renderPills() {
  applyObsVisibility();
  ui.pillObs.dataset.s = obsHidden() ? 'off' : statusOf('obs')[0];
  ui.pillPc.dataset.s = statusOf('pc')[0];
  ui.pillObs.setAttribute('aria-label', 'OBS: ' + statusOf('obs')[1]);
  ui.pillPc.setAttribute('aria-label', 'PC: ' + statusOf('pc')[1]);
  document.body.classList.toggle('demo', S.demo);
}
function renderOnAir() {
  const bits = [];
  const now = Date.now();
  if (M.stream.active) bits.push(h('span', { class: 'oa live' + (M.stream.reconnecting ? ' warn' : '') }, h('i'), M.stream.reconnecting ? 'RECONECTANDO' : 'AO VIVO', h('b', null, fmtTime(M.stream.ms + (now - M.stream.at)))));
  if (M.rec.active) bits.push(h('span', { class: 'oa rec' + (M.rec.paused ? ' paused' : '') }, h('i'), M.rec.paused ? 'PAUSADO' : 'REC', h('b', null, fmtTime(M.rec.ms + (M.rec.paused ? 0 : now - M.rec.at)))));
  if (M.stream.active && M.stream.kbps) bits.push(h('span', { class: 'oa kb' }, (M.stream.kbps / 1000).toFixed(1).replace('.', ',') + ' Mb/s'));
  ui.onair.replaceChildren(...bits);
  ui.onair.classList.toggle('show', bits.length > 0 && obs.status === 'ready');
}

/* ---------- conexão (folha rápida ao tocar nas pílulas) ---------- */
function connSheet(kind) {
  const [st, txt] = statusOf(kind);
  let s;
  const body = h('div', { class: 'stack' });
  if (kind === 'obs') {
    body.append(h('div', { class: 'conn-line', 'data-s': st }, h('i'), h('div', null, h('b', null, 'OBS Studio'), h('small', null, txt + (obs.url ? ' · ' + obs.url.replace('ws://', '') : '')))));
    if (obs.status === 'auth') body.append(h('p', { class: 'muted' }, 'A senha salva não confere com a do OBS. Abra Ajustes para digitar a senha atual, ou deixe o Garra Hub buscar a senha sozinho.'));
    if (obs.status === 'offline') body.append(h('p', { class: 'muted' }, 'Confira se o OBS está aberto no PC e se o servidor WebSocket está ligado (OBS › Ferramentas › Configurações do servidor WebSocket).'));
    body.append(h('button', { class: 'btn primary block', onclick: () => { s.close(); connectObs(true); } }, ic('refresh'), 'Reconectar'));
  } else {
    body.append(h('div', { class: 'conn-line', 'data-s': st }, h('i'), h('div', null, h('b', null, (cfg.hub && cfg.hub.name) || 'Garra Hub'), h('small', null, txt + (cfg.hub ? ' · ' + cfg.hub.host : '')))));
    if (hub.status === 'offline') body.append(h('p', { class: 'muted' }, 'Abra o Garra Hub no PC e confira se o celular está no mesmo Wi-Fi.'));
    if (!cfg.hub || hub.status === 'unpaired') body.append(h('button', { class: 'btn primary block', onclick: () => { s.close(); startFlow('pc'); } }, ic('link'), 'Conectar ao PC'));
    else body.append(h('button', { class: 'btn primary block', onclick: () => { s.close(); hub.poll(); } }, ic('refresh'), 'Atualizar'));
  }
  body.append(h('button', { class: 'btn ghost block', onclick: () => { s.close(); openSettings(); } }, ic('gear'), 'Abrir ajustes'));
  s = sheet({ title: kind === 'obs' ? 'Conexão com o OBS' : 'Conexão com o PC', body });
}

/* ================= aba LIVE ================= */
function buildLive() {
  const v = ui.views.live;
  ui.live = {};
  const L = ui.live;
  L.offline = h('div', { class: 'card notice' });
  L.streamCard = h('div', { class: 'card stream' });
  L.streamState = h('div', { class: 'stream-state' });
  L.streamBtnBox = h('div', { class: 'stream-actions' });
  L.startBtn = h('button', { class: 'btn primary xl', onclick: startStream }, ic('live'), h('span', null, 'Iniciar transmissão'));
  L.stopBtn = HoldButton('Segure para encerrar', stopStream, 'danger xl', 'stop');
  L.stopTap = h('button', { class: 'btn danger xl', onclick: stopStream }, ic('stop'), h('span', null, 'Encerrar transmissão'));
  L.streamCard.append(L.streamState, L.streamBtnBox);

  L.recTile = h('button', { class: 'qt', onclick: toggleRec }, h('span', { class: 'qt-ic' }, ic('rec')), h('span', { class: 'qt-t' }, 'Gravar'), h('span', { class: 'qt-s' }, 'Parado'));
  L.recPause = h('button', { class: 'qt-mini', 'aria-label': 'Pausar gravação', onclick: e => { e.stopPropagation(); pauseRec(); } }, ic('pause'));
  L.recTile.append(L.recPause);
  L.micTile = h('button', { class: 'qt', onclick: toggleMic }, h('span', { class: 'qt-ic' }, ic('mic')), h('span', { class: 'qt-t' }, 'Microfone'), h('span', { class: 'qt-s' }, '—'));
  L.replayTile = h('button', { class: 'qt', onclick: replayAction }, h('span', { class: 'qt-ic' }, ic('replay')), h('span', { class: 'qt-t' }, 'Replay'), h('span', { class: 'qt-s' }, ''));
  L.vcamTile = h('button', { class: 'qt', onclick: toggleVcam }, h('span', { class: 'qt-ic' }, ic('vcam')), h('span', { class: 'qt-t' }, 'Câmera virtual'), h('span', { class: 'qt-s' }, ''));
  L.quick = h('div', { class: 'quick' }, L.micTile, L.recTile, L.replayTile, L.vcamTile);

  L.stats = h('div', { class: 'stats' });
  L.transBtn = h('button', { class: 'btn primary', onclick: transition }, ic('swap'), 'Transição');
  L.sceneHead = sectionHead('Cenas');
  L.scenes = h('div', { class: 'scenes' });
  L.itemsHead = sectionHead('Fontes');
  L.items = h('div', { class: 'card list' });

  L.main = h('div', { class: 'live-grid' },
    h('div', { class: 'col' }, L.streamCard, L.quick, L.stats),
    h('div', { class: 'col' }, L.sceneHead, L.scenes, L.itemsHead, L.items));
  v.append(L.offline, L.main);
}
function renderLive() {
  if (!ui.live) return;
  const L = ui.live;
  renderOnAir();
  const ready = obs.status === 'ready';
  L.main.style.display = ready ? '' : 'none';
  L.offline.style.display = ready ? 'none' : '';
  if (!ready) { renderObsNotice(L.offline); return; }

  // transmissão
  const s = M.stream;
  L.streamCard.classList.toggle('is-live', s.active);
  L.streamState.replaceChildren(
    h('div', { class: 'ss-top' }, h('span', { class: 'badge ' + (s.active ? (s.reconnecting ? 'warn' : 'live') : '') }, h('i'), s.active ? (s.reconnecting ? 'Reconectando' : 'Ao vivo') : 'Fora do ar'), h('span', { class: 'ss-scene' }, ic('layers'), M.program || '—')),
    h('div', { class: 'ss-time' }, s.active ? fmtTime(s.ms + (Date.now() - s.at)) : '0:00')
  );
  const want = s.active ? (cfg.prefs.confirmStop ? L.stopBtn : L.stopTap) : L.startBtn;
  if (L.streamBtnBox.firstChild !== want) L.streamBtnBox.replaceChildren(want);

  // atalhos rápidos
  const mic = M.inputs.find(x => x.name === M.mic);
  L.micTile.classList.toggle('danger', !!(mic && mic.muted));
  L.micTile.classList.toggle('on', !!(mic && !mic.muted));
  L.micTile.querySelector('.qt-ic').replaceChildren(ic(mic && mic.muted ? 'micoff' : 'mic'));
  L.micTile.querySelector('.qt-t').textContent = mic && mic.muted ? 'Mic mudo' : 'Microfone';
  L.micTile.querySelector('.qt-s').textContent = M.mic || 'Escolha em Ajustes';

  L.recTile.classList.toggle('rec', M.rec.active && !M.rec.paused);
  L.recTile.classList.toggle('paused', M.rec.active && M.rec.paused);
  L.recTile.querySelector('.qt-ic').replaceChildren(ic(M.rec.active ? 'stop' : 'rec'));
  L.recTile.querySelector('.qt-t').textContent = M.rec.active ? 'Parar gravação' : 'Gravar';
  L.recTile.querySelector('.qt-s').textContent = M.rec.active ? (M.rec.paused ? 'Pausado · ' : '') + fmtTime(M.rec.ms + (M.rec.paused ? 0 : Date.now() - M.rec.at)) : 'Parado';
  L.recPause.style.display = M.rec.active ? '' : 'none';
  L.recPause.replaceChildren(ic(M.rec.paused ? 'play' : 'pause'));

  L.replayTile.style.display = M.replay.avail ? '' : 'none';
  L.replayTile.classList.toggle('on', M.replay.active);
  L.replayTile.querySelector('.qt-t').textContent = M.replay.active ? 'Salvar replay' : 'Replay';
  L.replayTile.querySelector('.qt-s').textContent = M.replay.active ? 'Buffer ativo' : 'Toque para ativar';
  L.vcamTile.style.display = M.vcam.avail ? '' : 'none';
  L.vcamTile.classList.toggle('on', M.vcam.active);
  L.vcamTile.querySelector('.qt-s').textContent = M.vcam.active ? 'Ligada' : 'Desligada';

  // cenas
  L.sceneHead.replaceChildren(...[h('h2', null, 'Cenas'), M.studio ? h('span', { class: 'tag' }, 'Modo estúdio') : h('span', { class: 'count' }, M.scenes.length || ''), M.studio ? L.transBtn : null].filter(Boolean));
  if (!M.scenes.length) L.scenes.replaceChildren(emptyState('layers', 'Nenhuma cena', 'Crie cenas no OBS e elas aparecem aqui.'));
  else {
    if (L.scenes.querySelector('.empty')) L.scenes.replaceChildren();
    listSync(L.scenes, M.scenes, n => n,
      n => h('button', { class: 'scene', onclick: () => pickScene(n) }, h('span', { class: 'sc-name' }), h('span', { class: 'sc-tag' })),
      (el, n) => {
        const prog = n === M.program, prev = M.studio && n === M.preview;
        el.classList.toggle('prog', prog); el.classList.toggle('prev', prev);
        el.querySelector('.sc-name').textContent = n;
        el.querySelector('.sc-tag').textContent = prog ? 'No ar' : prev ? 'Prévia' : '';
        el.setAttribute('aria-pressed', prog ? 'true' : 'false');
      });
  }
  // fontes
  L.itemsHead.replaceChildren(h('h2', null, 'Fontes'), h('span', { class: 'count' }, M.itemsScene ? (M.studio ? 'Prévia: ' : '') + M.itemsScene : ''));
  if (!M.items.length) L.items.replaceChildren(emptyState('eye', 'Nenhuma fonte nesta cena'));
  else {
    if (L.items.querySelector('.empty')) L.items.replaceChildren();
    listSync(L.items, M.items, it => M.itemsScene + '#' + it.id,
      it => {
        const sw = Switch(v => { act(req('SetSceneItemEnabled', { sceneName: M.itemsScene, sceneItemId: it.id, sceneItemEnabled: v })); }, it.name);
        const row = h('div', { class: 'row', onclick: () => sw.click() }, h('span', { class: 'row-ic' }), h('span', { class: 'row-t' }), sw);
        row._sw = sw; return row;
      },
      (el, it) => {
        el.querySelector('.row-t').textContent = it.name;
        el.querySelector('.row-ic').replaceChildren(ic(it.on ? 'eye' : 'eyeoff'));
        el.classList.toggle('dim', !it.on);
        el._sw.set(it.on);
      });
  }
}
function renderObsNotice(box) {
  const st = obs.status;
  let title, text, actions;
  if (st === 'connecting') { title = 'Conectando ao OBS…'; text = obs.url ? obs.url.replace('ws://', '') : ''; actions = [h('div', { class: 'spinner' })]; }
  else if (st === 'auth') { title = 'Senha do OBS'; text = obs.detail + '. Atualize a senha em Ajustes.'; actions = [h('button', { class: 'btn primary', onclick: openSettings }, 'Abrir ajustes')]; }
  else if (st === 'offline' || st === 'error') {
    title = 'OBS fora do ar';
    text = 'Abra o OBS no PC. Se já estiver aberto, confira em Ferramentas › Configurações do servidor WebSocket se o servidor está ligado.';
    actions = [h('button', { class: 'btn primary', onclick: () => connectObs(true) }, ic('refresh'), 'Tentar agora')];
  } else { title = 'OBS não conectado'; text = 'Conecte o Garra ao OBS para controlar cenas, live, gravação e áudio.'; actions = [h('button', { class: 'btn primary', onclick: () => startFlow(cfg.hub ? 'obs' : 'pc') }, ic('link'), 'Conectar')]; }
  box.replaceChildren(h('div', { class: 'notice-ic' }, st === 'connecting' ? mark('spin') : ic(st === 'idle' ? 'link' : 'alert')), h('h3', null, title), h('p', null, text), h('div', { class: 'row-actions' }, actions));
}
function renderStats() {
  if (!ui.live) return;
  const st = M.stats;
  if (!st || obs.status !== 'ready') { ui.live.stats.replaceChildren(); return; }
  const drop = M.stream.total ? (M.stream.skipped / M.stream.total * 100) : (st.outputTotalFrames ? st.outputSkippedFrames / st.outputTotalFrames * 100 : 0);
  const cells = [
    ['CPU', Math.round(st.cpuUsage || 0) + '%', (st.cpuUsage || 0) > 80],
    ['FPS', Math.round(st.activeFps || 0), (st.activeFps || 0) < 25],
    ['Perdidos', drop.toFixed(1).replace('.', ',') + '%', drop > 2],
    ['Envio', M.stream.active ? (M.stream.kbps / 1000).toFixed(1).replace('.', ',') + ' Mb/s' : '—', false]
  ];
  ui.live.stats.replaceChildren(...cells.map(c => h('div', { class: 'stat' + (c[2] ? ' warn' : '') }, h('small', null, c[0]), h('b', null, c[1]))));
}

/* ================= aba ÁUDIO (mixer do OBS) ================= */
function buildAudio() {
  ui.audio = { head: sectionHead('Mixer do OBS'), list: h('div', { class: 'mixer' }), note: h('div', { class: 'card notice' }) };
  ui.views.audio.append(ui.audio.note, ui.audio.head, ui.audio.list);
}
function renderAudio() {
  if (!ui.audio) return;
  const A = ui.audio, ready = obs.status === 'ready';
  A.note.style.display = ready ? 'none' : '';
  A.head.style.display = A.list.style.display = ready ? '' : 'none';
  if (!ready) { renderObsNotice(A.note); return; }
  if (!M.inputs.length) { A.list.replaceChildren(emptyState('sliders', 'Nenhuma fonte de áudio', 'Fontes de áudio do OBS aparecem aqui.')); A.list._map = null; return; }
  if (A.list.querySelector('.empty')) A.list.replaceChildren();
  listSync(A.list, M.inputs, i => i.name,
    i => {
      const el = h('div', { class: 'strip' });
      el._db = h('span', { class: 'db' });
      el._mute = h('button', { class: 'mute', 'aria-label': 'Mudo', onclick: () => { haptic('tap'); const cur = M.inputs.find(x => x.name === i.name); act(req('SetInputMute', { inputName: i.name, inputMuted: !(cur && cur.muted) })); } });
      el._meter = h('div', { class: 'meter' }, h('i'));
      el._sl = Slider({
        label: 'Volume de ' + i.name,
        onLive: p => { el._db.textContent = fmtDb(p2mul(p)); },
        onChange: p => { const cur = M.inputs.find(x => x.name === i.name); if (cur) cur.mul = p2mul(p); req('SetInputVolume', { inputName: i.name, inputVolumeMul: p2mul(p) }).catch(e => fail(e)); }
      });
      el.addEventListener('dblclick', e => { if (e.target.closest('.slider')) { req('SetInputVolume', { inputName: i.name, inputVolumeMul: 1 }).catch(() => { }); } });
      el.append(h('div', { class: 'strip-top' }, h('span', { class: 'strip-name' }), el._db, el._mute), el._meter, el._sl);
      return el;
    },
    (el, i) => {
      const nm = el.querySelector('.strip-name'); nm.textContent = i.name; if (i.name === M.mic) nm.append(h('span', { class: 'mini-tag' }, 'MIC'));
      el._db.textContent = fmtDb(i.mul);
      el._sl.set(mul2p(i.mul));
      el.classList.toggle('muted', i.muted);
      el._mute.replaceChildren(ic(i.muted ? 'voloff' : 'vol'));
      el._mute.setAttribute('aria-pressed', i.muted ? 'true' : 'false');
      el._meter.style.display = cfg.prefs.meters ? '' : 'none';
    });
}
let meterRaf = 0;
function scheduleMeters() {
  if (meterRaf || S.tab !== 'audio') return;
  meterRaf = requestAnimationFrame(() => {
    meterRaf = 0;
    const map = ui.audio.list._map; if (!map) return;
    map.forEach((el, name) => {
      const pk = M.meters[name] || 0;
      const db = pk > 0 ? 20 * Math.log10(pk) : -60;
      const w = Math.max(0, Math.min(1, (db + 60) / 60));
      const bar = el._meter.firstChild;
      bar.style.transform = 'scaleX(' + w.toFixed(3) + ')';
      el._meter.dataset.lvl = db > -6 ? 'hot' : db > -20 ? 'warm' : 'ok';
    });
  });
}

/* ================= aba PC (Garra Hub) ================= */
function buildPc() {
  const P = ui.pc = {};
  P.note = h('div', { class: 'card notice' });
  P.body = h('div', { class: 'pc-grid' });
  // saída
  P.outName = h('button', { class: 'dev', onclick: () => devSheet('out') }, ic('headphones'), h('span'), ic('down'));
  P.outMute = h('button', { class: 'mute', 'aria-label': 'Mudo', onclick: () => hubCmd({ a: 'mute', target: 'out', v: !(hub.state && hub.state.out.mute) }) });
  P.outPct = h('span', { class: 'db' });
  P.outSl = Slider({ label: 'Volume do PC', onLive: p => { P.outPct.textContent = pct(p); }, onChange: p => hubCmd({ a: 'vol', target: 'out', v: +p.toFixed(3) }, true) });
  P.outCard = h('div', { class: 'card vol-card' }, h('div', { class: 'vc-head' }, h('small', null, 'Volume do PC'), P.outPct, P.outMute), P.outSl, P.outName);
  // microfone
  P.inName = h('button', { class: 'dev', onclick: () => devSheet('in') }, ic('mic'), h('span'), ic('down'));
  P.inMute = h('button', { class: 'mute', 'aria-label': 'Mudo', onclick: () => hubCmd({ a: 'mute', target: 'in', v: !(hub.state && hub.state.in && hub.state.in.mute) }) });
  P.inPct = h('span', { class: 'db' });
  P.inSl = Slider({ label: 'Volume do microfone', onLive: p => { P.inPct.textContent = pct(p); }, onChange: p => hubCmd({ a: 'vol', target: 'in', v: +p.toFixed(3) }, true) });
  P.inCard = h('div', { class: 'card vol-card' }, h('div', { class: 'vc-head' }, h('small', null, 'Microfone do Windows'), P.inPct, P.inMute), P.inSl, P.inName);
  // mídia
  P.mediaTitle = h('div', { class: 'media-t' });
  P.playBtn = h('button', { class: 'mbtn big', 'aria-label': 'Tocar ou pausar', onclick: () => hubCmd({ a: 'media', k: 'play' }) }, ic('play'));
  P.media = h('div', { class: 'card media' },
    h('div', { class: 'media-info' }, h('span', { class: 'media-ic' }, ic('music')), h('div', null, h('small', null, 'Tocando agora'), P.mediaTitle)),
    h('div', { class: 'media-ctl' },
      h('button', { class: 'mbtn', 'aria-label': 'Anterior', onclick: () => hubCmd({ a: 'media', k: 'prev' }) }, ic('prev')),
      P.playBtn,
      h('button', { class: 'mbtn', 'aria-label': 'Próxima', onclick: () => hubCmd({ a: 'media', k: 'next' }) }, ic('next'))));
  // apps
  P.appsHead = sectionHead('Volume por aplicativo');
  P.apps = h('div', { class: 'mixer apps' });
  // sistema
  const sys = [['lock', 'lock', 'Bloquear PC', true], ['screenoff', 'screenoff', 'Desligar tela', true], ['screenshot', 'camera', 'Captura de tela', false], ['obs', 'aperture', 'Abrir OBS', false]];
  P.sys = h('div', { class: 'sys' }, sys.map(x => h('button', { class: 'sysbtn', onclick: () => sysAction(x[0], x[2], x[3]) }, ic(x[1]), h('span', null, x[2]))));
  const pw = [['sleep', 'moon', 'Suspender'], ['restart', 'refresh', 'Reiniciar'], ['shutdown', 'power', 'Desligar']];
  P.power = h('div', { class: 'sys power' }, pw.map(x => h('button', { class: 'sysbtn' + (x[0] === 'shutdown' ? ' danger' : ''), onclick: () => powerAction(x[0], x[2]) }, ic(x[1]), h('span', null, x[2]))));
  P.wakeHint = h('p', { class: 'hint wake-hint' });
  P.body.append(
    h('div', { class: 'col' }, P.outCard, P.inCard, P.media, sectionHead('Sistema'), P.sys, sectionHead('Energia do PC'), P.power, P.wakeHint),
    h('div', { class: 'col' }, P.appsHead, P.apps));
  ui.views.pc.append(P.note, P.body);
}
async function hubCmd(o, quiet) {
  if (!quiet) haptic('tap');
  try { await hub.cmd(o); if (!quiet) hub.poll(); } catch (e) { fail(e); }
}
function sysAction(k, label, confirmIt) {
  const go = () => { haptic('confirm'); hub.cmd({ a: 'sys', k }).then(() => toast(label + ' ✓', 'good')).catch(e => fail(e)); };
  if (confirmIt) confirmSheet({ title: label + '?', text: k === 'lock' ? 'O Windows vai para a tela de bloqueio.' : 'O monitor apaga até você mexer no mouse ou teclado.', ok: label, onOk: go });
  else go();
}
/* ---------- ligar / desligar o PC ---------- */
function rememberWake(st) {
  const w = st && st.pc && st.pc.wake;
  if (!w || !w.mac || !cfg.hub) return;
  const old = cfg.hub.wake || {};
  if (old.mac !== w.mac || old.bcast !== w.bcast || old.wired !== w.wired) { cfg.hub.wake = { mac: w.mac, bcast: w.bcast, wired: !!w.wired }; Cfg.save(); }
}
const POWER_TEXT = {
  sleep: 'O PC entra em suspensão na hora. Para acordar, use Ligar o PC aqui no app (se o Wake-on-LAN estiver ativo) ou mexa no mouse.',
  restart: 'O Windows avisa na tela e reinicia em 30 segundos. Dá para cancelar aqui até lá.',
  shutdown: 'O Windows avisa na tela e desliga em 30 segundos. Dá para cancelar aqui até lá. Salve o que estiver aberto.'
};
function powerAction(k, label) {
  confirmSheet({
    title: label + ' o PC?', text: POWER_TEXT[k], ok: label, okClass: k === 'sleep' ? 'primary' : 'danger',
    onOk: async () => {
      haptic('confirm');
      try {
        await hub.cmd({ a: 'sys', k });
        if (k === 'sleep') { toast('PC suspenso', 'good'); return; }
        let left = 30, s, t;
        const count = h('b', null, '30');
        const stop = () => { clearInterval(t); if (s) s.close(); };
        s = sheet({
          title: (k === 'restart' ? 'Reiniciando' : 'Desligando') + ' o PC', sub: 'Faltam alguns segundos. Ainda dá tempo de cancelar.',
          body: h('div', { class: 'stack' }, h('div', { class: 'power-count' }, count, h('small', null, 'segundos')),
            h('button', { class: 'btn primary block', onclick: async () => { stop(); try { await hub.cmd({ a: 'sys', k: 'cancel' }); toast('Cancelado ✓', 'good'); } catch (e) { fail(e); } } }, ic('x'), 'Cancelar'),
            h('button', { class: 'btn ghost block', onclick: stop }, 'Fechar'))
        });
        t = setInterval(() => { left--; count.textContent = String(Math.max(0, left)); if (left <= 0) stop(); }, 1000);
      } catch (e) { fail(e); }
    }
  });
}
async function wakePc() {
  const w = cfg.hub && cfg.hub.wake;
  if (!w || !Native || !Native.canWake()) return;
  haptic('confirm');
  const r = await Native.wake(w.mac, w.bcast);
  if (r && r.ok) { toast('Sinal enviado. O PC deve ligar em alguns segundos.', 'good'); setTimeout(() => hub.poll(), 8000); setTimeout(() => hub.poll(), 25000); }
  else toast('Não consegui enviar o sinal: ' + ((r && r.error) || 'sem Wi-Fi?'), 'bad');
}
function wakeHelp() {
  sheet({
    title: 'Ligar o PC pelo celular', sub: 'Usa o Wake-on-LAN, que precisa ser ativado uma vez no PC.',
    body: h('div', { class: 'card list help' },
      h('p', null, '1. Use o PC ligado no cabo de rede (pelo Wi-Fi quase nenhum PC liga).'),
      h('p', null, '2. Na BIOS/UEFI, ative "Wake on LAN" ou "Power On By PCI-E".'),
      h('p', null, '3. No Windows: Gerenciador de Dispositivos › placa de rede › Propriedades › Gerenciamento de energia: marque "Permitir que este dispositivo ative o computador" e "Somente pacote mágico". Em Avançado, ative "Wake on Magic Packet".'),
      h('p', null, '4. Se não ligar depois de desligado, desative a "Inicialização rápida" do Windows (Opções de energia).'),
      h('p', null, 'O celular e o PC precisam estar na mesma rede. O app guarda os dados da placa automaticamente quando está conectado ao Hub.'))
  });
}

function devSheet(flow) {
  const st = hub.state; if (!st) return;
  const list = flow === 'in' ? st.ins : st.outs;
  let s;
  s = sheet({
    title: flow === 'in' ? 'Microfone padrão' : 'Saída de áudio', sub: 'Muda o dispositivo padrão do Windows',
    body: h('div', { class: 'card list' }, (list || []).map(d => h('button', { class: 'row', onclick: () => { s.close(); hubCmd({ a: 'dev', flow, id: d.id }); } },
      h('span', { class: 'row-ic' }, ic(flow === 'in' ? 'mic' : 'headphones')), h('span', { class: 'row-t' }, d.name), d.def ? h('span', { class: 'row-check' }, ic('check')) : null)))
  });
}
function renderPc() {
  if (!ui.pc) return;
  const P = ui.pc, st = hub.state, ready = hub.status === 'ready' && st;
  P.note.style.display = ready ? 'none' : '';
  P.body.style.display = ready ? '' : 'none';
  if (!ready) {
    let title, text, actions;
    if (hub.status === 'connecting') { title = 'Conectando ao PC…'; text = cfg.hub ? cfg.hub.host : ''; actions = [h('div', { class: 'spinner' })]; }
    else if (hub.status === 'offline') {
      const canWake = cfg.hub && cfg.hub.wake && Native && Native.canWake();
      title = 'PC fora do ar'; text = canWake ? 'O PC pode estar desligado. Toque em Ligar o PC, ou abra o Garra Hub e confira se o celular está no mesmo Wi-Fi.' : 'Abra o Garra Hub no PC e confira se o celular está no mesmo Wi-Fi.';
      actions = [canWake ? h('button', { class: 'btn primary', onclick: wakePc }, ic('power'), 'Ligar o PC') : null, h('button', { class: canWake ? 'btn ghost' : 'btn primary', onclick: () => hub.poll() }, ic('refresh'), 'Tentar agora')].filter(Boolean);
    }
    else if (hub.status === 'unpaired') { title = 'Pareamento expirou'; text = 'O PC não reconhece mais este aparelho. Pareie de novo com o código do Hub.'; actions = [h('button', { class: 'btn primary', onclick: () => startFlow('pc') }, ic('link'), 'Parear de novo')]; }
    else { title = 'Controle o Windows pelo celular'; text = 'Com o Garra Hub aberto no PC, você muda o volume de cada app, troca fone e microfone, controla a música e bloqueia a tela.'; actions = [h('button', { class: 'btn primary', onclick: () => startFlow('pc') }, ic('link'), 'Conectar ao PC'), h('button', { class: 'btn ghost', onclick: hubHelp }, 'Como instalar')]; }
    P.note.replaceChildren(h('div', { class: 'notice-ic' }, hub.status === 'connecting' ? mark('spin') : ic('pc')), h('h3', null, title), h('p', null, text), h('div', { class: 'row-actions' }, actions));
    return;
  }
  const wk = st.pc && st.pc.wake;
  const canWake = Native && Native.canWake();
  P.wakeHint.replaceChildren(
    wk ? (wk.wired ? 'Para ligar o PC desligado, este app usa o Wake-on-LAN (placa ' + wk.mac + '). ' : 'O PC está no Wi-Fi: ligar à distância costuma só funcionar com cabo de rede. ') : 'Ligar à distância precisa de cabo de rede e Wake-on-LAN. ',
    canWake ? '' : 'Ligar o PC só funciona no app Android. ',
    h('button', { class: 'linkbtn', onclick: wakeHelp }, 'Como ativar'));
  P.outName.querySelector('span').textContent = st.out ? st.out.name : 'Sem saída';
  P.outPct.textContent = st.out ? pct(st.out.vol) : '';
  P.outSl.set(st.out ? st.out.vol : 0);
  P.outCard.classList.toggle('muted', !!(st.out && st.out.mute));
  P.outMute.replaceChildren(ic(st.out && st.out.mute ? 'voloff' : 'vol'));
  P.inCard.style.display = st.in ? '' : 'none';
  if (st.in) {
    P.inName.querySelector('span').textContent = st.in.name;
    P.inPct.textContent = pct(st.in.vol);
    P.inSl.set(st.in.vol);
    P.inCard.classList.toggle('muted', !!st.in.mute);
    P.inMute.replaceChildren(ic(st.in.mute ? 'micoff' : 'mic'));
  }
  P.mediaTitle.textContent = (st.media && st.media.title) || 'Nada tocando no momento';
  P.playBtn.replaceChildren(ic(st.media && st.media.playing ? 'pause' : 'play'));
  const apps = st.apps || [];
  if (!apps.length) { P.apps.replaceChildren(emptyState('vol', 'Nenhum app tocando som', 'Os apps aparecem aqui quando emitem áudio.')); P.apps._map = null; }
  else {
    if (P.apps.querySelector('.empty')) P.apps.replaceChildren();
    listSync(P.apps, apps, a => a.key,
      a => {
        const el = h('div', { class: 'strip app' });
        el._pct = h('span', { class: 'db' });
        el._mute = h('button', { class: 'mute', 'aria-label': 'Mudo', onclick: () => { const cur = (hub.state.apps || []).find(x => x.key === a.key); hubCmd({ a: 'mute', target: 'app', key: a.key, v: !(cur && cur.mute) }); } });
        el._sl = Slider({ label: 'Volume de ' + a.name, onLive: p => { el._pct.textContent = pct(p); }, onChange: p => hubCmd({ a: 'vol', target: 'app', key: a.key, v: +p.toFixed(3) }, true) });
        let iconEl;
        if (a.icon && hub.imgUrl) { iconEl = h('img', { class: 'app-ic', alt: '', src: hub.imgUrl('/api/icon', { key: a.key }) }); iconEl.onerror = () => iconEl.replaceWith(avatar(a.name, 'app-ic')); }
        else iconEl = avatar(a.name, 'app-ic');
        el.append(h('div', { class: 'strip-top' }, iconEl, h('span', { class: 'strip-name' }), el._pct, el._mute), el._sl);
        return el;
      },
      (el, a) => {
        el.querySelector('.strip-name').textContent = a.name;
        el._pct.textContent = pct(a.vol);
        el._sl.set(a.vol);
        el.classList.toggle('muted', !!a.mute);
        el._mute.replaceChildren(ic(a.mute ? 'voloff' : 'vol'));
      });
  }
}
function hubHelp() {
  const steps = [
    ['Baixe o Garra Hub no PC', APP.hubDownloadUrl ? 'Toque no botão abaixo para abrir o link de download.' : 'O Hub vem junto do convite do teste beta (arquivo "Garra Hub").'],
    ['Abra o Garra Hub', 'Se o Windows perguntar sobre o Firewall, marque "Redes privadas" e clique em Permitir.'],
    ['Mesmo Wi-Fi', 'O celular e o PC precisam estar na mesma rede.'],
    ['Pareie', 'Toque em "Conectar ao PC" e digite o código de 6 números que aparece no Hub.']
  ];
  let s;
  s = sheet({
    title: 'Instalar o Garra Hub', sub: 'O app do Windows que deixa o celular controlar o PC',
    body: h('div', { class: 'stack' },
      h('ol', { class: 'steps' }, steps.map(x => h('li', null, h('b', null, x[0]), h('span', null, x[1])))),
      APP.hubDownloadUrl ? h('button', { class: 'btn primary block', onclick: () => openExternal(APP.hubDownloadUrl) }, ic('ext'), 'Baixar o Garra Hub') : null,
      h('button', { class: 'btn primary block', onclick: () => { s.close(); startFlow('pc'); } }, ic('search'), 'Procurar meu PC'))
  });
}

/* ================= aba ATALHOS ================= */
function buildApps() {
  const A = ui.apps = {};
  A.note = h('div', { class: 'card notice' });
  A.search = h('input', { type: 'search', placeholder: 'Buscar jogo ou app', 'aria-label': 'Buscar', oninput: () => { S.lsearch = A.search.value.trim().toLowerCase(); renderApps(); } });
  A.seg = h('div', { class: 'seg' }, [['all', 'Todos'], ['fav', 'Favoritos'], ['steam', 'Steam'], ['epic', 'Epic'], ['custom', 'Meus']].map(x => h('button', { 'data-k': x[0], onclick: () => { S.lfilter = x[0]; renderApps(); } }, x[1])));
  A.tools = h('div', { class: 'apps-tools' }, h('label', { class: 'search' }, ic('search'), A.search), h('button', { class: 'iconbtn', 'aria-label': 'Atualizar lista', onclick: () => loadLaunchers(true) }, ic('refresh')));
  A.grid = h('div', { class: 'tiles' });
  A.body = h('div', null, A.tools, A.seg, A.grid);
  ui.views.apps.append(A.note, A.body);
}
async function loadLaunchers(force) {
  if (hub.status !== 'ready') { renderApps(); return; }
  if (S.launchers && !force) { renderApps(); return; }
  S.loadingL = true; renderApps();
  try { const j = await hub.get('/api/launchers'); S.launchers = j.items || []; }
  catch (e) { fail(e, 'Lista de atalhos'); }
  S.loadingL = false; renderApps();
}
function renderApps() {
  if (!ui.apps) return;
  const A = ui.apps;
  const ready = hub.status === 'ready';
  A.note.style.display = ready ? 'none' : '';
  A.body.style.display = ready ? '' : 'none';
  if (!ready) {
    A.note.replaceChildren(h('div', { class: 'notice-ic' }, ic('gamepad')), h('h3', null, 'Abra jogos e apps do PC'), h('p', null, 'Conecte o Garra Hub para ver sua biblioteca da Steam, da Epic e os programas que você adicionar no Hub.'),
      h('div', { class: 'row-actions' }, h('button', { class: 'btn primary', onclick: () => startFlow('pc') }, ic('link'), 'Conectar ao PC')));
    return;
  }
  A.seg.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.k === S.lfilter));
  if (S.loadingL && !S.launchers) { A.grid.replaceChildren(h('div', { class: 'loading' }, h('div', { class: 'spinner' }), 'Lendo sua biblioteca…')); A.grid._map = null; return; }
  let items = (S.launchers || []).slice();
  const favs = cfg.favs || [];
  if (S.lfilter === 'fav') items = items.filter(i => favs.indexOf(i.id) >= 0);
  else if (S.lfilter !== 'all') items = items.filter(i => i.src === S.lfilter);
  if (S.lsearch) items = items.filter(i => i.name.toLowerCase().indexOf(S.lsearch) >= 0);
  items.sort((a, b) => (favs.indexOf(b.id) >= 0) - (favs.indexOf(a.id) >= 0) || a.name.localeCompare(b.name, 'pt'));
  if (!items.length) {
    A.grid.replaceChildren(emptyState('gamepad', S.lsearch ? 'Nada encontrado' : S.lfilter === 'fav' ? 'Sem favoritos ainda' : 'Nenhum atalho',
      S.lfilter === 'custom' || !(S.launchers || []).length ? 'No Garra Hub, clique em "Adicionar programa" para criar atalhos seus.' : S.lfilter === 'fav' ? 'Toque num jogo e marque a estrela.' : ''));
    A.grid._map = null; return;
  }
  if (A.grid.querySelector('.empty,.loading')) A.grid.replaceChildren();
  listSync(A.grid, items, i => i.id,
    i => {
      const art = h('div', { class: 'tile-art' });
      if (i.img && hub.imgUrl) { const im = h('img', { alt: '', loading: 'lazy', src: hub.imgUrl('/api/img', { id: i.id }) }); im.onerror = () => im.replaceWith(avatar(i.name, 'big')); art.append(im); }
      else art.append(avatar(i.name, 'big'));
      return h('button', { class: 'tile', onclick: () => launchSheet(i) }, art, h('span', { class: 'tile-t' }), h('span', { class: 'tile-src' }), h('span', { class: 'tile-fav' }, ic('star')));
    },
    (el, i) => {
      el.querySelector('.tile-t').textContent = i.name;
      el.querySelector('.tile-src').textContent = i.src === 'steam' ? 'Steam' : i.src === 'epic' ? 'Epic Games' : 'Atalho';
      el.classList.toggle('fav', favs.indexOf(i.id) >= 0);
    });
}
function launchSheet(i) {
  const isFav = () => (cfg.favs || []).indexOf(i.id) >= 0;
  let s;
  const favBtn = h('button', { class: 'btn ghost block', onclick: () => { const f = cfg.favs || (cfg.favs = []); const k = f.indexOf(i.id); if (k >= 0) f.splice(k, 1); else f.push(i.id); Cfg.save(); haptic('tap'); favBtn.lastChild.textContent = isFav() ? 'Remover dos favoritos' : 'Adicionar aos favoritos'; renderApps(); } }, ic('star'), h('span', null, isFav() ? 'Remover dos favoritos' : 'Adicionar aos favoritos'));
  s = sheet({
    title: i.name, sub: i.src === 'steam' ? 'Steam' : i.src === 'epic' ? 'Epic Games' : 'Atalho do Hub',
    body: h('div', { class: 'stack' },
      h('button', { class: 'btn primary block xl', onclick: () => { s.close(); haptic('confirm'); hub.cmd({ a: 'launch', id: i.id }).then(() => toast('Abrindo ' + i.name + ' no PC', 'good')).catch(e => fail(e)); } }, ic('play'), 'Abrir no PC'),
      favBtn)
  });
}

/* ================= AJUSTES ================= */
function openSettings() {
  const page = h('div', { class: 'page', role: 'dialog', 'aria-modal': 'true' });
  const close = () => { dropLayer(close); page.classList.remove('in'); setTimeout(() => page.remove(), 220); renderAll(); };
  const body = h('div', { class: 'page-body' });
  page.append(h('div', { class: 'page-head' }, h('button', { class: 'iconbtn', 'aria-label': 'Voltar', onclick: close }, ic('left')), h('h2', null, 'Ajustes')), body);

  const group = (title, ...rows) => h('div', { class: 'group' }, h('h4', null, title), h('div', { class: 'card list' }, rows));
  const row = (iconName, title, sub, right, onClick) => h(onClick ? 'button' : 'div', { class: 'row', onclick: onClick || null }, h('span', { class: 'row-ic' }, ic(iconName)), h('span', { class: 'row-t' }, title, sub ? h('small', null, sub) : null), right || (onClick ? ic('right', 'chev') : null));
  const prefSwitch = (key, after) => { const sw = Switch(v => { cfg.prefs[key] = v; Cfg.save(); if (after) after(v); }); sw.set(!!cfg.prefs[key]); return sw; };

  // conexões
  const [ps, pt] = statusOf('pc'), [os, ot] = statusOf('obs');
  const pcRow = row('pc', (cfg.hub && cfg.hub.name) || 'Computador (Garra Hub)', pt + (cfg.hub ? ' · ' + cfg.hub.host : ''), h('span', { class: 'dot', 'data-s': ps }), () => { close(); startFlow('pc'); });
  const obsHost = h('input', { type: 'text', inputmode: 'url', placeholder: 'IP do PC', value: cfg.obs.host || '', autocapitalize: 'off', autocomplete: 'off' });
  const obsPort = h('input', { type: 'number', inputmode: 'numeric', placeholder: '4455', value: cfg.obs.port || 4455 });
  const obsPass = h('input', { type: 'password', placeholder: 'Senha do WebSocket', value: cfg.obs.pass || '', autocomplete: 'off' });
  const fromHub = Switch(v => { cfg.obs.fromHub = v; Cfg.save(); manual.style.display = v ? 'none' : ''; if (v) connectObs(true); });
  fromHub.set(cfg.obs.fromHub && !!cfg.hub);
  const hideManual = S.demo || (cfg.obs.fromHub && cfg.hub);
  const manual = h('div', { class: 'form', style: hideManual ? 'display:none' : '' },
    h('label', null, h('span', null, 'Endereço'), obsHost), h('label', null, h('span', null, 'Porta'), obsPort),
    h('label', null, h('span', null, 'Senha'), h('div', { class: 'pass' }, obsPass, h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Mostrar senha', onclick: () => { obsPass.type = obsPass.type === 'password' ? 'text' : 'password'; } }, ic('eye')))),
    h('button', { class: 'btn primary block', onclick: () => { cfg.obs.host = obsHost.value.trim(); cfg.obs.port = +obsPort.value || 4455; cfg.obs.pass = obsPass.value; cfg.obs.fromHub = false; Cfg.save(); connectObs(true); toast('Conectando ao OBS…'); } }, 'Salvar e conectar'));

  const micSel = h('select', { 'aria-label': 'Microfone principal' }, h('option', { value: '' }, 'Automático'), M.inputs.map(i => h('option', { value: i.name, selected: cfg.prefs.mic === i.name ? 'selected' : null }, i.name)));
  micSel.addEventListener('change', () => { cfg.prefs.mic = micSel.value; Cfg.save(); pickMic(); renderLive(); });
  const sizeSeg = h('div', { class: 'seg small' }, [['s', 'P'], ['m', 'M'], ['l', 'G']].map(x => h('button', { class: cfg.prefs.size === x[0] ? 'on' : '', onclick: e => { cfg.prefs.size = x[0]; Cfg.save(); applyPrefs(); sizeSeg.querySelectorAll('button').forEach(b => b.classList.toggle('on', b === e.currentTarget)); } }, x[1])));

  let obsBox;
  const useObsSw = Switch(v => { cfg.useObs = v; Cfg.save(); obsBox.style.display = v ? '' : 'none'; if (v) { connectObs(true); } else if (obs.disconnect) obs.disconnect(); renderAll(); });
  useObsSw.set(!obsHidden());
  const useObsRow = row('aperture', 'Usar o OBS', 'Mostra as abas Live e Áudio. Desligue se usa só o controle do Windows.', useObsSw);
  body.append(
    group('Conexões', pcRow, useObsRow,
      obsBox = h('div', { class: 'row col', style: obsHidden() ? 'display:none' : '' }, h('div', { class: 'row-inner' }, h('span', { class: 'row-ic' }, ic('aperture')), h('span', { class: 'row-t' }, 'OBS Studio', h('small', null, ot + (obs.url ? ' · ' + obs.url.replace('ws://', '') : ''))), h('span', { class: 'dot', 'data-s': os })),
        cfg.hub ? h('div', { class: 'row-inner sub' }, h('span', { class: 'row-t' }, 'Pegar endereço e senha pelo Hub', h('small', null, 'Recomendado: o Hub lê a configuração do OBS sozinho')), fromHub) : null,
        manual)),
    h('div', { style: obsHidden() ? 'display:none' : '' }, group('Live e controles',
      row('mic', 'Microfone principal', 'Usado no botão Microfone da aba Live', micSel),
      row('alert', 'Confirmar antes de iniciar e encerrar', 'Evita entrar ou sair do ar sem querer', prefSwitch('confirmStop', () => renderLive())),
      row('sliders', 'Medidores de áudio', 'Mostra o nível de cada fonte no mixer', prefSwitch('meters', v => { obs.setMeters && obs.setMeters(v && S.tab === 'audio'); renderAudio(); })))),
    group('Aparelho',
      row('keypad', 'Vibração ao tocar', null, prefSwitch('haptics')),
      row('screenoff', 'Manter a tela ligada', 'Enquanto o Garra estiver aberto', prefSwitch('awake', v => Native && Native.keepAwake(v))),
      row('grid', 'Tamanho dos botões', null, sizeSeg)),
    group('Ajuda',
      row('pc', 'Como instalar o Garra Hub', null, null, hubHelp),
      row('sparkles', S.demo ? 'Sair do modo demonstração' : 'Modo demonstração', 'Experimente tudo sem OBS nem PC', null, () => { close(); setDemo(!S.demo); }),
      row('refresh', 'Refazer a configuração inicial', null, null, () => { close(); startFlow('full'); })),
    group('Sobre',
      row('info', APP.name + ' ' + APP.version, 'Versão de teste. Seu feedback ajuda muito!'),
      row('lock', 'Política de privacidade', 'Nenhum dado sai da sua rede', null, () => openExternal(new URL(APP.privacyUrl, location.href).href)),
      APP.supportEmail ? row('ext', 'Enviar feedback', APP.supportEmail, null, () => openExternal('mailto:' + APP.supportEmail + '?subject=' + encodeURIComponent('Garra ' + APP.version))) : null,
      cfg.hub ? row('trash', 'Esquecer este PC', 'Apaga o pareamento deste aparelho', null, () => confirmSheet({ title: 'Esquecer o PC?', text: 'Você vai precisar do código do Hub para parear de novo.', ok: 'Esquecer', okClass: 'danger', onOk: () => { cfg.hub = null; Cfg.save(); connectHub(); close(); } })) : null)
  );
  document.body.append(page);
  requestAnimationFrame(() => page.classList.add('in'));
  pushLayer(close);
}
function applyPrefs() {
  document.body.dataset.size = cfg.prefs.size || 'm';
  if (Native) Native.keepAwake(!!cfg.prefs.awake);
}

/* ================= CONFIGURAÇÃO GUIADA (primeiro uso, parear PC, OBS) ================= */
function startFlow(mode) {
  const ov = h('div', { class: 'flow', role: 'dialog', 'aria-modal': 'true' });
  const box = h('div', { class: 'flow-box' });
  const top = h('div', { class: 'flow-top' });
  ov.append(top, box);
  const hist = [];
  const close = () => { dropLayer(back); ov.classList.remove('in'); setTimeout(() => ov.remove(), 220); renderAll(); };
  const back = () => { if (hist.length > 1) { hist.pop(); show(hist.pop(), true); } else if (mode !== 'full' || cfg.onboarded) close(); };
  const backBtn = h('button', { class: 'iconbtn', 'aria-label': 'Voltar', onclick: back }, ic('left'));
  const skip = h('button', { class: 'link', onclick: close }, 'Fechar');
  const F = { picked: null };

  function show(step, isBack) {
    hist.push(step);
    const el = steps[step]();
    el.classList.add('step');
    box.replaceChildren(el);
    top.replaceChildren(hist.length > 1 || mode !== 'full' ? backBtn : h('span'), h('div', { class: 'grow' }), (mode !== 'full' || cfg.onboarded) ? skip : h('span'));
    el.classList.add(isBack ? 'from-left' : 'from-right');
    const f = el.querySelector('[autofocus]'); if (f) setTimeout(() => f.focus(), 250);
  }
  const hero = (iconEl, title, text) => h('div', { class: 'hero' }, h('div', { class: 'hero-ic' }, iconEl), h('h1', null, title), text ? h('p', null, text) : null);

  const steps = {
    welcome: () => h('div', null,
      h('div', { class: 'hero big' }, h('div', { class: 'logo-big' }, mark()), h('h1', null, 'garra'), h('p', null, 'Seu painel de live na palma da mão.')),
      h('ul', { class: 'feats' },
        h('li', null, h('span', null, ic('live')), h('div', null, h('b', null, 'OBS completo'), h('small', null, 'Cenas, live, gravação, replay, fontes e mixer'))),
        h('li', null, h('span', null, ic('pc')), h('div', null, h('b', null, 'Mixer do Windows'), h('small', null, 'Volume de cada app, fone, microfone e música'))),
        h('li', null, h('span', null, ic('gamepad')), h('div', null, h('b', null, 'Atalhos do PC'), h('small', null, 'Abra jogos da Steam, Epic e seus programas')))),
      h('div', { class: 'flow-actions' },
        h('button', { class: 'btn primary block xl', onclick: () => show(S.hubOrigin ? 'search' : 'hub') }, 'Começar'),
        h('button', { class: 'btn ghost block', onclick: () => { close(); cfg.onboarded = true; Cfg.save(); setDemo(true); } }, ic('sparkles'), 'Ver demonstração'))),

    hub: () => h('div', null,
      hero(ic('pc'), 'Instale o Garra Hub no PC', 'É um app pequeno para Windows. Com ele, o Garra encontra seu PC sozinho, pega a senha do OBS e libera o mixer do Windows.'),
      h('ol', { class: 'steps' },
        h('li', null, h('b', null, 'Abra o Garra Hub no PC'), h('span', null, APP.hubDownloadUrl ? 'Baixe pelo botão abaixo, se ainda não tiver.' : 'O arquivo vem junto do convite do teste.')),
        h('li', null, h('b', null, 'Permita no Firewall'), h('span', null, 'Na primeira vez, marque "Redes privadas" e clique em Permitir.')),
        h('li', null, h('b', null, 'Mesmo Wi-Fi'), h('span', null, 'Celular e PC conectados na mesma rede.'))),
      h('div', { class: 'flow-actions' },
        h('button', { class: 'btn primary block xl', onclick: () => show('search') }, ic('search'), 'Procurar meu PC'),
        APP.hubDownloadUrl ? h('button', { class: 'btn ghost block', onclick: () => openExternal(APP.hubDownloadUrl) }, ic('ext'), 'Baixar o Garra Hub') : null,
        h('button', { class: 'link', onclick: () => show('obsManual') }, 'Pular: conectar só ao OBS'))),

    search: () => {
      const list = h('div', { class: 'found' });
      const status = h('div', { class: 'searching' }, h('div', { class: 'radar' }, mark('spin')), h('p', null, 'Procurando na sua rede Wi-Fi…'));
      const manualIp = h('input', { type: 'text', inputmode: 'decimal', placeholder: 'Ex.: 192.168.0.10', autocapitalize: 'off' });
      const manualBox = h('div', { class: 'form' }, h('label', null, h('span', null, 'IP do PC (aparece no Hub)'), manualIp),
        h('button', { class: 'btn ghost block', onclick: async () => {
          const ip = manualIp.value.trim(); if (!ip) return;
          try { const j = await HubClient.hello(ip, APP.hubPort); if (j.app !== 'garra-hub') throw new Error('x'); F.picked = { host: ip, port: APP.hubPort, name: j.name || ip }; show('pin'); }
          catch (e) { haptic('reject'); toast('Não achei o Hub nesse IP. Ele está aberto?', 'bad'); }
        } }, 'Conectar por IP'));
      const el = h('div', null, hero(ic('wifi'), 'Encontrar seu PC', null), status, list, h('details', { class: 'manual' }, h('summary', null, 'Digitar o IP manualmente'), manualBox));
      (async () => {
        await sleep(30);
        if (!el.isConnected) return;
        if (S.hubOrigin) {
          F.picked = Object.assign({}, S.hubOrigin); status.remove();
          if (/^(localhost|127\.0\.0\.1|\[::1\])$/.test(S.hubOrigin.host)) { cfg.hub = { host: S.hubOrigin.host, port: S.hubOrigin.port, token: '', name: S.hubOrigin.name }; cfg.obs.fromHub = true; Cfg.save(); connectHub(); show('obs'); }
          else show('pin');
          return;
        }
        if (!Native) { status.replaceChildren(h('p', null, 'A busca automática funciona no app Android. Aqui, digite o IP que aparece no Garra Hub.')); el.querySelector('details').open = true; return; }
        const r = await discover();
        if (!el.isConnected) return;
        status.remove();
        if (!r.hubs.length && !r.obs.length) {
          list.append(h('div', { class: 'card notice small' }, h('h3', null, 'Nenhum PC encontrado'),
            h('ul', { class: 'checks' }, h('li', null, 'O Garra Hub está aberto no PC?'), h('li', null, 'Celular e PC estão no mesmo Wi-Fi?'), h('li', null, 'O Firewall do Windows permitiu o Hub?')),
            h('div', { class: 'row-actions' }, h('button', { class: 'btn primary', onclick: () => { hist.pop(); show('search'); } }, ic('refresh'), 'Procurar de novo'))));
          el.querySelector('details').open = true;
          return;
        }
        r.hubs.forEach(x => list.append(h('button', { class: 'found-item', onclick: () => { F.picked = x; show('pin'); } }, h('span', { class: 'fi-ic' }, ic('pc')), h('span', { class: 'fi-t' }, h('b', null, x.name), h('small', null, x.host + ' · Garra Hub')), ic('right', 'chev'))));
        r.obs.filter(o => !o.hasHub).forEach(o => list.append(h('button', { class: 'found-item', onclick: () => { F.obsHost = o.host; show('obsManual'); } }, h('span', { class: 'fi-ic' }, ic('aperture')), h('span', { class: 'fi-t' }, h('b', null, 'OBS em ' + o.host), h('small', null, 'Sem o Hub: só o controle do OBS')), ic('right', 'chev'))));
        if (r.hubs.length === 1 && !r.obs.filter(o => !o.hasHub).length) list.firstChild.classList.add('pulse');
      })();
      return el;
    },

    pin: () => {
      const inp = h('input', { class: 'pin', type: 'text', inputmode: 'numeric', pattern: '[0-9]*', maxlength: 6, autocomplete: 'one-time-code', 'aria-label': 'Código de 6 números', autofocus: true });
      const boxes = h('div', { class: 'pin-boxes', onclick: () => inp.focus() }, [0, 1, 2, 3, 4, 5].map(() => h('span')));
      const err = h('p', { class: 'err' });
      const btn = h('button', { class: 'btn primary block xl', disabled: true }, 'Parear');
      const paint = () => { const v = inp.value.replace(/\D/g, '').slice(0, 6); inp.value = v; [...boxes.children].forEach((b, i) => { b.textContent = v[i] || ''; b.classList.toggle('cur', i === v.length); }); btn.disabled = v.length !== 6; };
      const go = async () => {
        const pin = inp.value; if (pin.length !== 6) return;
        btn.disabled = true; btn.textContent = 'Pareando…';
        try {
          const j = await HubClient.pair(F.picked.host, F.picked.port, pin, Native ? Native.device() : (navigator.platform || 'Navegador'));
          if (!j.ok || !j.token) throw new Error(j.error || 'Código incorreto');
          cfg.hub = { host: F.picked.host, port: F.picked.port, token: j.token, name: j.name || F.picked.name };
          cfg.obs.fromHub = true; Cfg.save();
          haptic('confirm');
          connectHub();
          show('obs');
        } catch (e) {
          haptic('reject'); boxes.classList.remove('shake'); void boxes.offsetWidth; boxes.classList.add('shake');
          err.textContent = e.code === 403 || /c[oó]digo/i.test(e.message) ? 'Código incorreto. Confira o número no Hub.' : e.code === 429 ? 'Muitas tentativas. Aguarde um minuto.' : 'Não deu certo: ' + e.message;
          inp.value = ''; paint(); btn.textContent = 'Parear';
        }
      };
      inp.addEventListener('input', () => { err.textContent = ''; paint(); if (inp.value.length === 6) go(); });
      btn.addEventListener('click', go);
      setTimeout(paint);
      return h('div', null, hero(ic('keypad'), 'Digite o código do Hub', 'O código de 6 números aparece na janela do Garra Hub em ' + (F.picked ? F.picked.name : 'seu PC') + '.'), h('div', { class: 'pin-wrap' }, inp, boxes), err, h('div', { class: 'flow-actions' }, btn));
    },

    obs: () => {
      const st = h('div', { class: 'searching' }, h('div', { class: 'radar' }, mark('spin')), h('p', null, 'Conectando ao OBS pelo Hub…'));
      const el = h('div', null, hero(ic('aperture'), 'Conectar ao OBS', null), st);
      (async () => {
        let info = null;
        try { info = await hub.get('/api/obs'); } catch (e) { info = null; }
        if (!el.isConnected) return;
        if (info && info.found && info.enabled) {
          cfg.obs.fromHub = true; Cfg.save();
          await connectObs(true);
          const ok = await waitObs(7000);
          if (!el.isConnected) return;
          if (ok) { show('done'); return; }
          st.replaceChildren(h('div', { class: 'card notice small' }, h('h3', null, obs.status === 'auth' ? 'Senha do OBS não confere' : 'O OBS não respondeu'),
            h('p', null, obs.status === 'auth' ? 'Abra o Garra Hub e clique em "Atualizar" (ele relê a senha do OBS), ou digite a senha manualmente.' : 'O OBS está aberto no PC? Abra-o e toque em Tentar de novo.'),
            h('div', { class: 'row-actions' }, h('button', { class: 'btn primary', onclick: () => { hist.pop(); show('obs'); } }, ic('refresh'), 'Tentar de novo'), h('button', { class: 'btn ghost', onclick: () => show('obsManual') }, 'Digitar manualmente'))));
          return;
        }
        const msg = !info ? ['Não consegui falar com o Hub', 'Confira se o Garra Hub continua aberto.'] :
          !info.found ? ['OBS não encontrado no PC', 'Instale/abra o OBS Studio (versão 28 ou mais nova) no mesmo PC do Hub.'] :
            ['Ligue o servidor WebSocket do OBS', 'No OBS: Ferramentas › Configurações do servidor WebSocket › marque "Ativar servidor WebSocket" e clique em OK.'];
        st.replaceChildren(h('div', { class: 'card notice small' }, h('h3', null, msg[0]), h('p', null, msg[1]),
          h('div', { class: 'row-actions' }, h('button', { class: 'btn primary', onclick: () => { hist.pop(); show('obs'); } }, ic('refresh'), 'Tentar de novo'), h('button', { class: 'btn ghost', onclick: () => show('done') }, 'Fazer depois'))));
      })();
      el.append(h('div', { class: 'flow-actions' }, h('button', { class: 'link', onclick: () => { cfg.useObs = false; Cfg.save(); obs.disconnect && obs.disconnect(); show('done'); } }, 'Não uso o OBS — só o controle do Windows')));
      return el;
    },

    obsManual: () => {
      const host = h('input', { type: 'text', inputmode: 'decimal', placeholder: 'IP do PC, ex.: 192.168.0.10', value: F.obsHost || cfg.obs.host || (cfg.hub && cfg.hub.host) || '', autocapitalize: 'off', autocomplete: 'off' });
      const port = h('input', { type: 'number', inputmode: 'numeric', value: cfg.obs.port || 4455 });
      const pass = h('input', { type: 'password', placeholder: 'Senha do servidor WebSocket', value: cfg.obs.pass || '', autocomplete: 'off' });
      const err = h('p', { class: 'err' });
      const btn = h('button', { class: 'btn primary block xl' }, 'Conectar');
      btn.addEventListener('click', async () => {
        if (!host.value.trim()) { err.textContent = 'Digite o IP do PC.'; return; }
        cfg.obs = { host: host.value.trim(), port: +port.value || 4455, pass: pass.value, fromHub: false }; Cfg.save();
        btn.disabled = true; btn.textContent = 'Conectando…'; err.textContent = '';
        await connectObs(true);
        const ok = await waitObs(7000);
        btn.disabled = false; btn.textContent = 'Conectar';
        if (ok) show('done');
        else { haptic('reject'); err.textContent = obs.status === 'auth' ? 'Senha incorreta.' : 'O OBS não respondeu nesse endereço.'; }
      });
      return h('div', null, hero(ic('aperture'), 'Dados do OBS', 'No OBS: Ferramentas › Configurações do servidor WebSocket › "Mostrar informações de conexão".'),
        h('div', { class: 'form' }, h('label', null, h('span', null, 'IP do servidor'), host), h('label', null, h('span', null, 'Porta'), port),
          h('label', null, h('span', null, 'Senha'), h('div', { class: 'pass' }, pass, h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Mostrar senha', onclick: () => { pass.type = pass.type === 'password' ? 'text' : 'password'; } }, ic('eye'))))),
        err, h('div', { class: 'flow-actions' }, btn));
    },

    done: () => {
      cfg.onboarded = true; Cfg.save();
      const line = (ok, t, s) => h('li', { class: ok ? 'ok' : '' }, h('span', null, ic(ok ? 'check' : 'info')), h('div', null, h('b', null, t), h('small', null, s)));
      return h('div', null, h('div', { class: 'hero big' }, h('div', { class: 'logo-big ok' }, ic('check')), h('h1', null, 'Tudo pronto!'), h('p', null, 'Você pode mudar isso quando quiser em Ajustes.')),
        h('ul', { class: 'feats sum' },
          line(obs.status === 'ready', 'OBS', obs.status === 'ready' ? 'Conectado' : 'Não conectado — dá para ligar depois'),
          line(!!cfg.hub, 'PC (Garra Hub)', cfg.hub ? 'Pareado com ' + cfg.hub.name : 'Não pareado — o mixer do Windows fica desligado')),
        h('div', { class: 'flow-actions' }, h('button', { class: 'btn primary block xl', onclick: close }, 'Abrir o painel')));
    }
  };

  document.body.append(ov);
  requestAnimationFrame(() => ov.classList.add('in'));
  pushLayer(back);
  show(mode === 'full' ? 'welcome' : mode === 'pc' ? 'search' : (cfg.hub ? 'obs' : 'obsManual'));
}
function waitObs(ms) {
  return new Promise(res => {
    if (obs.status === 'ready') { res(true); return; }
    const t0 = Date.now();
    const iv = setInterval(() => {
      if (obs.status === 'ready') { clearInterval(iv); res(true); }
      else if (obs.status === 'auth' || Date.now() - t0 > ms) { clearInterval(iv); res(false); }
    }, 150);
  });
}

/* ================= conexões ================= */
async function connectObs(force) {
  if (S.demo) { obs.connect(); return; }
  if (cfg.useObs === false) { obs.disconnect(); renderAll(); return; }
  let host = cfg.obs.host, port = cfg.obs.port || 4455, pass = cfg.obs.pass;
  if (cfg.obs.fromHub && cfg.hub) {
    try {
      const info = await hub.get('/api/obs');
      if (info && info.found) {
        host = cfg.hub.host === '127.0.0.1' || cfg.hub.host === 'localhost' ? '127.0.0.1' : cfg.hub.host;
        port = info.port || 4455; pass = info.auth ? (info.password || '') : '';
        cfg.obs.host = host; cfg.obs.port = port; cfg.obs.pass = pass; Cfg.save();
      }
    } catch (e) { /* usa o que estiver salvo */ }
  }
  if (!host) { obs.disconnect(); renderAll(); return; }
  if (force || obs.status !== 'ready') obs.connect(host, port, pass);
}
function connectHub() {
  if (S.demo) { hub.configure({ host: 'demo' }); return; }
  hub.configure(cfg.hub);
}

/* ================= modo demonstração ================= */
let unbind = [];
function bindClients() {
  unbind.forEach(f => f()); unbind = [];
  unbind.push(obs.on('status', () => { renderPills(); renderLive(); renderAudio(); }));
  unbind.push(obs.on('ready', () => { if (!cfg.obsSeen) { cfg.obsSeen = true; Cfg.save(); } if (cfg.useObs === false) { cfg.useObs = true; Cfg.save(); } renderPills(); obsLoad(); startObsPolling(); if (S.tab === 'audio') obs.setMeters(cfg.prefs.meters); }));
  unbind.push(obs.on('lost', () => { toast('Conexão com o OBS caiu — tentando de novo…', 'warn'); }));
  unbind.push(obs.on('event', onObsEvent));
  unbind.push(hub.on('status', s => { renderPills(); renderPc(); renderApps(); if (s === 'ready' && S.tab === 'apps') loadLaunchers(false); }));
  unbind.push(hub.on('state', st => { rememberWake(st); renderPc(); }));
}
function setDemo(on) {
  if (on === S.demo) return;
  obs.disconnect && obs.disconnect(true); hub.configure && hub.configure(null);
  S.demo = on; S.launchers = null; M = freshModel();
  obs = on ? new DemoObs() : realObs;
  hub = on ? new DemoHub() : realHub;
  bindClients();
  renderAll();
  connectHub(); connectObs(true);
  if (on) toast('Modo demonstração ligado'); else toast('Modo demonstração desligado');
}

/* ================= relógio, visibilidade e início ================= */
setInterval(() => { if (obs.status === 'ready' && (M.stream.active || M.rec.active)) { renderOnAir(); if (S.tab === 'live') renderLive(); } }, 1000);
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) { if (!S.demo) { if (obs.status !== 'ready') obs.reconnectNow(); hub.poll && hub.poll(); } }
});
window.garraResume = () => { if (!S.demo) { if (obs.status !== 'ready') obs.reconnectNow(); if (hub.cfg) hub.poll(); } };

async function detectHubOrigin() {
  if (!/^https?:$/.test(location.protocol)) return;
  try {
    const port = location.port || (location.protocol === 'https:' ? 443 : 80);
    const j = await HubClient.hello(location.hostname, port);
    if (j && j.app === 'garra-hub') {
      S.hubOrigin = { host: location.hostname, port: +port, name: j.name || location.hostname };
      const local = /^(localhost|127\.0\.0\.1|\[::1\])$/.test(location.hostname);
      if (local && (!cfg.hub || cfg.hub.host !== location.hostname)) {
        cfg.hub = { host: location.hostname, port: +port, token: '', name: j.name || 'Este PC' };
        cfg.obs.fromHub = true; cfg.onboarded = true; Cfg.save();
      }
    }
  } catch (e) { }
}

async function boot() {
  applyPrefs();
  buildShell();
  bindClients();
  await detectHubOrigin();
  renderAll();
  const demoParam = /[?&]demo\b/.test(location.search);
  if (demoParam) { cfg.onboarded = true; setDemo(true); return; }
  connectHub();
  connectObs(false);
  if (!cfg.onboarded) startFlow('full');
}
window.__garra = { obs: () => obs, hub: () => hub, model: () => M, cfg: () => cfg };
boot();

})();
